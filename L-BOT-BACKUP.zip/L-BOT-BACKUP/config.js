import { config } from 'dotenv';
import { existsSync } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
config();

const rootDir = path.dirname(fileURLToPath(import.meta.url));
const resolveFromRoot = (file) => (path.isAbsolute(file) ? file : path.resolve(rootDir, file));

const numberFromEnv = (value, fallback) => {
  if (value === undefined || value === null || String(value).trim() === '') return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const bannerFile = resolveFromRoot(process.env.BANNER_FILE || './assets/banner.jpg');

export default {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,

  // Si se define, los comandos se registran también en este servidor al instante.
  guildId: process.env.GUILD_ID || null,

  // Marca / estética
  brandName: process.env.BRAND_NAME || 'L-BOT SHOP',
  brandTagline: process.env.BRAND_TAGLINE || 'Sistema de Backups',
  footerIconUrl: process.env.FOOTER_ICON_URL || process.env.BRAND_ICON_URL || null,
  // Imagen de banner: URL remota o archivo local (se adjunta al mensaje)
  bannerUrl: process.env.BANNER_URL || null,
  localBanner: existsSync(bannerFile) ? bannerFile : null,
  customEmojis: process.env.CUSTOM_EMOJIS !== 'false',

  // Backups
  backupInterval: numberFromEnv(process.env.BACKUP_INTERVAL_MINUTES, 60) * 60_000,
  maxBackupsPerGuild: numberFromEnv(process.env.MAX_BACKUPS_PER_GUILD, 10),
  backupLogChannelId: process.env.BACKUP_LOG_CHANNEL_ID || null,
  backupDirectory: process.env.BACKUP_DIRECTORY || './backups',
  backupCooldown: numberFromEnv(process.env.BACKUP_COOLDOWN_SECONDS, 30) * 1000,
};

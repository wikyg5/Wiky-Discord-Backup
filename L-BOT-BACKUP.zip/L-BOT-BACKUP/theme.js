import { EmbedBuilder } from 'discord.js';
import path from 'path';
import config from './config.js';
import { E } from './emojis.js';

/* ────────────────────────────────────────────────────────────────
   Paleta monocroma (negro, gris y blanco)
   ──────────────────────────────────────────────────────────────── */
export const COLORS = {
  primary: 0x000000,   // barra negra principal
  secondary: 0x0d0d0f, // casi negro
  accent: 0x1a1a1d,    // gris profundo
  success: 0x000000,
  danger: 0x000000,
  warning: 0x000000,
  neutral: 0x2a2a2e,
  dark: 0x000000,
  white: 0xffffff,
  muted: 0x9a9aa2,
};

export const BRAND = config.brandName;
export const TAGLINE = config.brandTagline;
export const BANNER = config.bannerUrl
  ?? (config.localBanner ? `attachment://${path.basename(config.localBanner)}` : null);

const MAX_TITLE = 256;
const MAX_DESCRIPTION = 4096;
const MAX_FIELD_VALUE = 1024;

export const truncate = (text = '', max = MAX_DESCRIPTION) => {
  const string = String(text ?? '');
  return string.length > max ? `${string.slice(0, max - 1)}…` : string;
};

export const code = (value) => `\`${value}\``;
export const bold = (value) => `**${value}**`;
export const quote = (value) => `> ${String(value).replace(/\n/g, '\n> ')}`;
export const bullets = (items = []) => items.map((item) => `• ${item}`).join('\n');

/* Jerarquía tipográfica minimalista:
   - small(): texto pequeño y gris para etiquetas y notas
   - label(): etiqueta en negrita y mayúsculas
   - rule: separador sutil                                          */
export const small = (text) => `-# ${text}`;
export const label = (text) => `**${String(text).toUpperCase()}**`;
export const rule = '-# ─────────────────────────────';

export const fmtDate = (timestamp) =>
  `<t:${Math.floor(Number(timestamp) / 1000)}:f>`;

export const fmtRelative = (timestamp) =>
  `<t:${Math.floor(Number(timestamp) / 1000)}:R>`;

export const fmtDuration = (ms) => {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(totalSeconds / 86_400);
  const hours = Math.floor((totalSeconds % 86_400) / 3_600);
  const minutes = Math.floor((totalSeconds % 3_600) / 60);
  const seconds = totalSeconds % 60;

  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (minutes) parts.push(`${minutes}m`);
  if (!days && !hours) parts.push(`${seconds}s`);
  return parts.join(' ');
};

export const progressBar = (current, total, size = 14) => {
  const ratio = total > 0 ? Math.min(1, Math.max(0, current / total)) : 0;
  const filled = Math.round(ratio * size);
  return `${'▰'.repeat(filled)}${'▱'.repeat(size - filled)} ${Math.round(ratio * 100)}%`;
};

export const guildIcon = (guild, size = 256) =>
  guild?.iconURL({ extension: 'png', size }) ?? undefined;

/**
 * Embed base con la estética de la marca.
 */
export function brandEmbed({
  title,
  description,
  color = COLORS.primary,
  fields = [],
  footer,
  footerIcon = config.footerIconUrl ?? undefined,
  thumbnail,
  image = BANNER ?? undefined,
  author,
  url,
  timestamp = true,
} = {}) {
  const embed = new EmbedBuilder().setColor(color);

  if (title) embed.setTitle(truncate(title, MAX_TITLE));
  if (description) embed.setDescription(truncate(description, MAX_DESCRIPTION));
  if (fields.length) {
    embed.addFields(
      fields.map((field) => ({
        name: truncate(field.name, MAX_TITLE),
        value: truncate(field.value || '\u200b', MAX_FIELD_VALUE),
        inline: Boolean(field.inline),
      })),
    );
  }
  if (thumbnail) embed.setThumbnail(thumbnail);
  if (image) embed.setImage(image);
  if (url) embed.setURL(url);
  if (author) embed.setAuthor(author);

  embed.setFooter({
    text: truncate(footer ? `${BRAND} • ${footer}` : `${BRAND} • ${TAGLINE}`, 2048),
    iconURL: footerIcon,
  });

  if (timestamp) embed.setTimestamp();
  return embed;
}

export const successEmbed = (opts = {}) =>
  brandEmbed({ color: COLORS.success, ...opts });

export const errorEmbed = (description, opts = {}) =>
  brandEmbed({
    color: COLORS.danger,
    title: `${E('cross')}  UPS, ALGO FALLÓ`,
    description,
    image: null,
    ...opts,
  });

export const warningEmbed = (opts = {}) =>
  brandEmbed({ color: COLORS.warning, ...opts });

export const infoEmbed = (opts = {}) =>
  brandEmbed({ color: COLORS.secondary, ...opts });

/**
 * Cabecera con el nombre de la marca y un icono a la izquierda.
 */
export const brandAuthor = (text) => ({
  name: `${BRAND}  •  ${text}`,
  iconURL: config.footerIconUrl ?? undefined,
});

/**
 * Separador visual usado dentro de las descripciones.
 */
export const divider = '━━━━━━━━━━━━━━━━━━━━━━━━━━';

export { config };

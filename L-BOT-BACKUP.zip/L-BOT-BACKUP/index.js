import {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  SlashCommandBuilder,
  MessageFlags,
  ChannelType,
  ActivityType,
  Events,
} from 'discord.js';
import config from './config.js';
import {
  createBackup,
  restoreBackup,
  startAutoBackup,
  listBackups,
  deleteBackup,
  loadBackup,
  BACKUP_VERSION,
} from './backup.js';
import { E, initEmojis, emojiOption } from './emojis.js';
import {
  COLORS,
  BRAND,
  brandEmbed,
  brandAuthor,
  successEmbed,
  errorEmbed,
  warningEmbed,
  infoEmbed,
  code,
  small,
  fmtDate,
  fmtRelative,
  fmtDuration,
  progressBar,
  guildIcon,
  truncate,
} from './theme.js';

const EPHEMERAL = { flags: MessageFlags.Ephemeral };
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Adjunta el banner local a los mensajes que lo usan como imagen.
 */
function withAssets(payload = {}) {
  if (!config.localBanner) return payload;

  const usesBanner = (payload.embeds ?? []).some((embed) => {
    const json = typeof embed?.toJSON === 'function' ? embed.toJSON() : embed;
    return typeof json?.image?.url === 'string' && json.image.url.startsWith('attachment://');
  });
  if (!usesBanner) return payload;

  const files = payload.files ? [...payload.files] : [];
  const alreadyAttached = files.some((file) =>
    (typeof file === 'string' ? file : file?.attachment) === config.localBanner,
  );
  if (!alreadyAttached) files.push(config.localBanner);

  return { ...payload, files };
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
  ],
});

/* ════════════════════════════════════════════════════════════════
   COMANDOS
   ════════════════════════════════════════════════════════════════ */

const commands = [
  new SlashCommandBuilder()
    .setName('hacerbackup')
    .setDescription('Crea una copia de seguridad completa del servidor'),

  new SlashCommandBuilder()
    .setName('backups')
    .setDescription('Ver y gestionar todas las copias de seguridad'),

  new SlashCommandBuilder()
    .setName('reconstruir')
    .setDescription('Restaura el servidor usando un código de backup')
    .addStringOption((option) =>
      option
        .setName('codigo')
        .setDescription('Código de la copia de seguridad')
        .setRequired(true)
        .setAutocomplete(true),
    )
    .addStringOption((option) =>
      option
        .setName('modo')
        .setDescription('Cómo aplicar la copia de seguridad')
        .addChoices(
          { name: 'Conservar lo existente (recomendado)', value: 'safe' },
          { name: 'Reemplazar todo el servidor', value: 'wipe' },
        ),
    )
    .addBooleanOption((option) =>
      option
        .setName('sanciones')
        .setDescription('Restaurar también las expulsiones (por defecto: sí)'),
    ),

  new SlashCommandBuilder()
    .setName('limpiar')
    .setDescription('Elimina todos los canales y roles del servidor'),

  new SlashCommandBuilder()
    .setName('darrol')
    .setDescription('Da un rol a todos los miembros del servidor')
    .addRoleOption((option) =>
      option.setName('rol').setDescription('El rol que se dará a todos los miembros').setRequired(true),
    ),

  new SlashCommandBuilder()
    .setName('estado')
    .setDescription('Consulta el estado y la configuración del bot'),

  new SlashCommandBuilder()
    .setName('ayuda')
    .setDescription('Muestra todos los comandos disponibles'),
].map((command) => command.setDefaultMemberPermissions(PermissionFlagsBits.Administrator).toJSON());

const rest = new REST({ version: '10' }).setToken(config.token);

/**
 * Sincroniza los comandos y elimina copias antiguas.
 * - Con GUILD_ID: solo comandos del servidor (se vacía la lista global).
 * - Sin GUILD_ID: comandos globales y se limpian los comandos de servidor
 *   que pudieran haber quedado registrados por versiones anteriores.
 */
async function syncCommands() {
  const names = commands.map((command) => `/${command.name}`).join(', ');

  if (config.guildId) {
    await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: commands });
    await rest.put(Routes.applicationCommands(config.clientId), { body: [] });
    console.log(`✅ Comandos sincronizados en el servidor: ${names}`);
    return;
  }

  await rest.put(Routes.applicationCommands(config.clientId), { body: commands });

  let cleared = 0;
  for (const guild of client.guilds.cache.values()) {
    try {
      await rest.put(Routes.applicationGuildCommands(config.clientId, guild.id), { body: [] });
      cleared++;
    } catch (error) {
      console.warn(`⚠️ No se pudieron limpiar los comandos de ${guild.name}: ${error.message}`);
    }
  }

  console.log(`✅ Comandos globales sincronizados: ${names}`);
  if (cleared) console.log(`🧹 Comandos duplicados eliminados en ${cleared} servidor(es).`);
}

/* ════════════════════════════════════════════════════════════════
   ARRANQUE
   ════════════════════════════════════════════════════════════════ */

client.once(Events.ClientReady, async () => {
  console.log(`✅ Bot conectado como ${client.user.tag}`);

  client.user.setPresence({
    activities: [{ name: 'protegiendo tu servidor', type: ActivityType.Watching }],
    status: 'online',
  });

  try {
    await initEmojis(client);
  } catch (error) {
    console.warn(`⚠️ Emojis personalizados no disponibles: ${error.message}`);
  }

  try {
    console.log('📝 Sincronizando comandos slash...');
    await syncCommands();
  } catch (error) {
    console.error('❌ Error al registrar comandos:', error);
  }

  startAutoBackup(client);
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) return await handleCommand(interaction);
    if (interaction.isAutocomplete()) return await handleAutocomplete(interaction);
    if (interaction.isButton()) return await handleButton(interaction);
    if (interaction.isAnySelectMenu()) return await handleSelectMenu(interaction);
  } catch (error) {
    console.error('❌ Error al procesar la interacción:', error);
    await respondError(interaction, error);
  }
});

client.on(Events.Error, (error) => console.error('❌ Error del cliente:', error));
process.on('unhandledRejection', (error) => console.error('❌ Promesa rechazada:', error));

/* ════════════════════════════════════════════════════════════════
   UTILIDADES
   ════════════════════════════════════════════════════════════════ */

function isAdmin(interaction) {
  if (!interaction.guild) return false;
  return Boolean(interaction.memberPermissions?.has(PermissionFlagsBits.Administrator));
}

async function guardAdmin(interaction) {
  if (isAdmin(interaction)) return true;
  const embed = errorEmbed(
    'Necesitas el permiso **Administrador** para usar esta función.',
    { title: `${E('lock')}  ACCESO RESTRINGIDO` },
  );
  if (interaction.deferred || interaction.replied) {
    await interaction.followUp(withAssets({ embeds: [embed], ...EPHEMERAL })).catch(() => {});
  } else {
    await interaction.reply(withAssets({ embeds: [embed], ...EPHEMERAL })).catch(() => {});
  }
  return false;
}

async function safeReply(interaction, payload) {
  try {
    await interaction.reply(withAssets(payload));
    return true;
  } catch {
    return false;
  }
}

async function respondError(interaction, error) {
  const embed = errorEmbed(truncate(error?.message ?? 'Error desconocido.', 1000));
  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(withAssets({ embeds: [embed], ...EPHEMERAL }));
    } else {
      await interaction.reply(withAssets({ embeds: [embed], ...EPHEMERAL }));
    }
  } catch {
    // la interacción pudo haber expirado
  }
}

async function safeEdit(interaction, payload) {
  try {
    await interaction.editReply(withAssets(payload));
    return true;
  } catch {
    return false;
  }
}

async function safeUpdate(interaction, payload) {
  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(withAssets(payload));
    } else {
      await interaction.update(withAssets(payload));
    }
    return true;
  } catch {
    return false;
  }
}

async function notifyInDM(user, embed) {
  try {
    await user.send(withAssets({ embeds: [embed] }));
    return true;
  } catch {
    return false;
  }
}

function countChannelTypes(channels = []) {
  const counts = { text: 0, voice: 0, forum: 0, announcement: 0, stage: 0, media: 0 };
  for (const channel of channels) {
    switch (channel.type) {
      case ChannelType.GuildText: counts.text++; break;
      case ChannelType.GuildVoice: counts.voice++; break;
      case ChannelType.GuildForum: counts.forum++; break;
      case ChannelType.GuildAnnouncement: counts.announcement++; break;
      case ChannelType.GuildStageVoice: counts.stage++; break;
      case ChannelType.GuildMedia: counts.media++; break;
      default: break;
    }
  }
  return counts;
}

function formatBytes(bytes = 0) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

const cooldowns = new Map();

function checkCooldown(guildId) {
  const last = cooldowns.get(guildId) ?? 0;
  const remaining = config.backupCooldown - (Date.now() - last);
  if (remaining > 0) return Math.ceil(remaining / 1000);
  return 0;
}

function markCooldown(guildId) {
  cooldowns.set(guildId, Date.now());
}

/* ════════════════════════════════════════════════════════════════
   VISTAS / EMBEDS
   ════════════════════════════════════════════════════════════════ */

function backupCreatedView(guild, backup) {
  const stats = backup.stats;
  const embed = brandEmbed({
    color: COLORS.primary,
    author: brandAuthor('BACKUP COMPLETADO'),
    title: `${E('shield')}  TU SERVIDOR ESTÁ A SALVO`,
    thumbnail: guildIcon(guild),
    description: [
      `> Copia completa de **${guild.name}** guardada correctamente.`,
      '',
      small('CÓDIGO DE RESTAURACIÓN'),
      `### ${code(backup.code)}`,
      '',
      `${E('calendar')}  ${fmtDate(backup.timestamp)}  ·  ${fmtRelative(backup.timestamp)}`,
      small('Guarda este código para restaurar el servidor cuando lo necesites.'),
    ].join('\n'),
    fields: [
      { name: `${E('chat')}  Canales`, value: code(stats.channels), inline: true },
      { name: `${E('folder')}  Categorías`, value: code(stats.categories), inline: true },
      { name: `${E('users')}  Roles`, value: code(stats.roles), inline: true },
      { name: `${E('lock')}  Permisos`, value: code(stats.permissionOverwrites), inline: true },
      { name: `${E('star')}  Emojis`, value: code(stats.emojis), inline: true },
      { name: `${E('flag')}  Sanciones`, value: code(stats.bans), inline: true },
    ],
    footer: 'Guardado localmente',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`bk:detail:${backup.code}`)
      .setLabel('Ver detalles')
      .setEmoji(E('search'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`bk:restore:${backup.code}`)
      .setLabel('Restaurar')
      .setEmoji(E('restore'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`bk:delete:${backup.code}`)
      .setLabel('Eliminar')
      .setEmoji(E('trash'))
      .setStyle(ButtonStyle.Danger),
  );

  return { embeds: [embed], components: [row] };
}

function backupDetailView(backup, { fromList = false } = {}) {
  const types = countChannelTypes(backup.channels);
  const stats = backup.stats ?? {};
  const overwrites =
    stats.permissionOverwrites ??
    backup.categories.reduce((total, channel) => total + (channel.permissionOverwrites?.length ?? 0), 0) +
      backup.channels.reduce((total, channel) => total + (channel.permissionOverwrites?.length ?? 0), 0);

  const channelLines = [
    types.text ? `${types.text} texto` : null,
    types.voice ? `${types.voice} voz` : null,
    types.forum ? `${types.forum} foros` : null,
    types.announcement ? `${types.announcement} anuncios` : null,
    types.stage ? `${types.stage} escenario` : null,
    types.media ? `${types.media} media` : null,
  ].filter(Boolean);

  const embed = brandEmbed({
    color: COLORS.secondary,
    author: brandAuthor('DETALLE DEL BACKUP'),
    title: `${E('list')}  INFORMACIÓN DE LA COPIA`,
    description: [
      `> Copia de **${backup.guildName}**.`,
      '',
      small('CÓDIGO'),
      `### ${code(backup.code)}`,
      '',
      `${E('calendar')}  ${fmtDate(backup.timestamp)}  ·  ${fmtRelative(backup.timestamp)}`,
      small(`${backup.trigger === 'auto' ? 'Backup automático' : 'Backup manual'} · ${backup.channels.length + backup.categories.length} elementos guardados`),
    ].join('\n'),
    fields: [
      { name: `${E('chat')}  Canales`, value: code(backup.channels.length), inline: true },
      { name: `${E('folder')}  Categorías`, value: code(backup.categories.length), inline: true },
      { name: `${E('users')}  Roles`, value: code(backup.roles.length), inline: true },
      { name: `${E('lock')}  Permisos`, value: code(overwrites), inline: true },
      { name: `${E('star')}  Emojis`, value: code(backup.emojis.length), inline: true },
      { name: `${E('flag')}  Sanciones`, value: code(backup.bans.length), inline: true },
      {
        name: `${E('chat')}  Distribución`,
        value: channelLines.length ? small(channelLines.join(' · ')) : small('Sin canales'),
        inline: false,
      },
      {
        name: `${E('settings')}  Configuración del servidor`,
        value: backup.guild
          ? `${E('check')} Verificación, notificaciones, filtro de contenido, canal AFK, canal del sistema y más.`
          : `${E('warning')} Este backup es antiguo y no guarda la configuración del servidor.`,
        inline: false,
      },
    ],
    footer: 'Los permisos se aplican al restaurar',
  });

  const buttons = [
    new ButtonBuilder()
      .setCustomId(`bk:restore:${backup.code}`)
      .setLabel('Restaurar')
      .setEmoji(E('restore'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`bk:delete:${backup.code}`)
      .setLabel('Eliminar')
      .setEmoji(E('trash'))
      .setStyle(ButtonStyle.Danger),
  ];

  if (fromList) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId('bk:list')
        .setLabel('Volver')
        .setEmoji(E('list'))
        .setStyle(ButtonStyle.Secondary),
    );
  }

  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(...buttons)],
  };
}

async function buildBackupListView(guild) {
  const backups = await listBackups();
  const guildBackups = backups.filter((backup) => backup.guildId === guild.id);
  const shown = (guildBackups.length ? guildBackups : backups).slice(0, 6);
  const total = guildBackups.length || backups.length;

  const embed = brandEmbed({
    color: COLORS.primary,
    author: brandAuthor('GESTOR DE BACKUPS'),
    title: `${E('list')}  TUS COPIAS DE SEGURIDAD`,
    thumbnail: guildIcon(guild),
    description: total
      ? `> Hay **${total}** copia(s) de seguridad guardadas. Selecciona una en el menú para gestionarla.`
      : '> Todavía no hay copias de seguridad. Crea la primera con el botón de abajo.',
    fields: shown.map((backup) => ({
      name: `${E('backup')}  ${code(backup.code)}  ·  ${truncate(backup.guildName, 60)}`,
      value: [
        `${E('calendar')}  ${fmtDate(backup.timestamp)}  ·  ${fmtRelative(backup.timestamp)}`,
        small(
          `${backup.channels} canales · ${backup.categories} categorías · ${backup.roles} roles · ` +
          `${backup.permissionOverwrites} permisos · ${formatBytes(backup.size)} · ` +
          `${backup.trigger === 'auto' ? 'automático' : 'manual'}`,
        ),
      ].join('\n'),
      inline: false,
    })),
    footer: total > shown.length ? `Mostrando ${shown.length} de ${total}` : 'Selecciona un backup para continuar',
  });

  const components = [];
  const pool = guildBackups.length ? guildBackups : backups;

  if (pool.length) {
    const select = new StringSelectMenuBuilder()
      .setCustomId('bk:select')
      .setPlaceholder('Selecciona una copia de seguridad…')
      .addOptions(
        pool.slice(0, 25).map((backup) => ({
          label: `${backup.code} • ${truncate(backup.guildName, 60)}`,
          description: truncate(
            `${new Date(backup.timestamp).toLocaleDateString('es-ES')} • ${backup.channels} canales • ${backup.roles} roles`,
            100,
          ),
          value: backup.code,
          ...(emojiOption('backup') ? { emoji: emojiOption('backup') } : {}),
        })),
      );
    components.push(new ActionRowBuilder().addComponents(select));
  }

  components.push(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('bk:new')
        .setLabel('Nuevo backup')
        .setEmoji(E('plus'))
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('bk:list')
        .setLabel('Actualizar')
        .setEmoji(E('restore'))
        .setStyle(ButtonStyle.Secondary),
    ),
  );

  return { embeds: [embed], components };
}

function restoreConfirmView(backup, guild, { mode = null, restoreBans = true } = {}) {
  const crossGuild = backup.guildId && backup.guildId !== guild.id;
  const overwrites =
    backup.stats?.permissionOverwrites ??
    backup.categories.reduce((total, channel) => total + (channel.permissionOverwrites?.length ?? 0), 0) +
      backup.channels.reduce((total, channel) => total + (channel.permissionOverwrites?.length ?? 0), 0);

  const embed = warningEmbed({
    author: brandAuthor('CONFIRMAR RESTAURACIÓN'),
    title: `${E('warning')}  RESTAURAR COPIA DE SEGURIDAD`,
    description: [
      `> Vas a restaurar ${code(backup.code)} en **${guild.name}**.`,
      crossGuild ? `> ${E('warning')} Esta copia pertenece a **${backup.guildName}**, otro servidor.` : null,
      '',
      small('MODO DE RESTAURACIÓN'),
      mode === 'safe'
        ? `${E('restore')}  **Conservar lo existente** · crea y actualiza sin borrar nada.`
        : mode === 'wipe'
          ? `${E('trash')}  **Reemplazar todo** · elimina los canales y roles actuales.`
          : [
              `${E('restore')}  **Conservar lo existente** · crea y actualiza sin borrar nada.`,
              `${E('trash')}  **Reemplazar todo** · elimina los canales y roles actuales.`,
            ].join('\n'),
      '',
      small(`EXPULSIONES · ${restoreBans ? 'se restaurarán' : 'no se restaurarán'}`),
    ].filter(Boolean).join('\n'),
    fields: [
      { name: `${E('chat')}  Canales`, value: code(backup.channels.length), inline: true },
      { name: `${E('users')}  Roles`, value: code(backup.roles.length), inline: true },
      { name: `${E('lock')}  Permisos`, value: code(overwrites), inline: true },
      { name: `${E('calendar')}  Fecha del backup`, value: `${fmtDate(backup.timestamp)}  ·  ${fmtRelative(backup.timestamp)}`, inline: false },
    ],
    footer: 'Elige un modo para continuar',
  });

  const bansFlag = restoreBans ? 1 : 0;
  const buttons = [];

  if (mode !== 'wipe') {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`bk:do:safe:${backup.code}:${bansFlag}`)
        .setLabel('Conservar y restaurar')
        .setEmoji(E('restore'))
        .setStyle(ButtonStyle.Secondary),
    );
  }

  if (mode !== 'safe') {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`bk:do:wipe:${backup.code}:${bansFlag}`)
        .setLabel('Reemplazar todo')
        .setEmoji(E('trash'))
        .setStyle(ButtonStyle.Danger),
    );
  }

  buttons.push(
    new ButtonBuilder()
      .setCustomId('bk:cancel')
      .setLabel('Cancelar')
      .setEmoji(E('cross'))
      .setStyle(ButtonStyle.Secondary),
  );

  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(...buttons)],
  };
}

function restoreResultView(result) {
  const hasErrors = result.errors > 0;
  const embed = brandEmbed({
    color: hasErrors ? COLORS.warning : COLORS.success,
    author: brandAuthor('RESTAURACIÓN FINALIZADA'),
    title: hasErrors
      ? `${E('warning')}  RESTAURACIÓN CON AVISOS`
      : `${E('check')}  SERVIDOR RESTAURADO`,
    description: [
      `> La copia ${code(result.backup.code)} se ha aplicado correctamente.`,
      small(`${result.mode === 'wipe' ? 'Reemplazo total' : 'Conservar existente'} · ${fmtDuration(result.durationMs)} de duración`),
    ].join('\n'),
    fields: [
      { name: `${E('users')}  Roles creados`, value: code(result.rolesCreated), inline: true },
      { name: `${E('settings')}  Roles actualizados`, value: code(result.rolesUpdated), inline: true },
      { name: `${E('chat')}  Canales creados`, value: code(result.channelsCreated), inline: true },
      { name: `${E('folder')}  Categorías`, value: code(result.categoriesCreated), inline: true },
      { name: `${E('lock')}  Permisos aplicados`, value: code(result.overwritesApplied), inline: true },
      { name: `${E('star')}  Emojis creados`, value: code(result.emojisCreated), inline: true },
      ...(result.bansRestored ? [{ name: `${E('flag')}  Sanciones restauradas`, value: code(result.bansRestored), inline: true }] : []),
      ...(result.errors ? [{ name: `${E('cross')}  Errores`, value: code(result.errors), inline: true }] : []),
      ...(result.warnings.length
        ? [{
            name: `${E('info')}  Avisos`,
            value: truncate(result.warnings.slice(0, 4).map((warning) => `• ${warning}`).join('\n'), 1024),
            inline: false,
          }]
        : []),
      ...(result.errorDetails.length
        ? [{
            name: `${E('warning')}  Detalle de errores`,
            value: truncate(result.errorDetails.slice(0, 4).map((detail) => `• ${detail}`).join('\n'), 1024),
            inline: false,
          }]
        : []),
    ],
    footer: 'La configuración del servidor se ha sincronizado',
  });

  return { embeds: [embed], components: [] };
}

function cleanConfirmView(guild) {
  const channels = guild.channels.cache.filter((channel) => !channel.isThread()).size;
  const roles = guild.roles.cache.filter((role) => role.id !== guild.id && !role.managed).size;

  const embed = warningEmbed({
    author: brandAuthor('ZONA DE PELIGRO'),
    title: `${E('trash')}  VACIAR EL SERVIDOR`,
    description: [
      '> Esta acción eliminará **todos los canales y roles** del servidor.',
      '> No se puede deshacer. Asegúrate de tener un backup reciente.',
      '',
      `**Canales afectados:** ${channels}`,
      `**Roles afectados:** ${roles}`,
    ].join('\n'),
    fields: [
      { name: `${E('star')}  Recomendación`, value: 'Crea un backup con `/hacerbackup` antes de continuar.', inline: false },
    ],
    footer: 'Confirma solo si estás totalmente seguro',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('cl:yes')
      .setLabel('Sí, vaciar servidor')
      .setEmoji(E('trash'))
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('cl:no')
      .setLabel('Cancelar')
      .setEmoji(E('cross'))
      .setStyle(ButtonStyle.Secondary),
  );

  return { embeds: [embed], components: [row] };
}

/* ════════════════════════════════════════════════════════════════
   COMANDOS — HANDLERS
   ════════════════════════════════════════════════════════════════ */

async function handleCommand(interaction) {
  if (!(await guardAdmin(interaction))) return;
  const { commandName } = interaction;

  switch (commandName) {
    case 'hacerbackup': return handleBackupCommand(interaction);
    case 'backups': return handleBackupsCommand(interaction);
    case 'reconstruir': return handleRestoreCommand(interaction);
    case 'limpiar': return handleCleanCommand(interaction);
    case 'darrol': return handleRoleCommand(interaction);
    case 'estado': return handleStatusCommand(interaction);
    case 'ayuda': return handleHelpCommand(interaction);
    default: return undefined;
  }
}

async function handleBackupCommand(interaction) {
  const remaining = checkCooldown(interaction.guildId);
  if (remaining) {
    return safeReply(interaction, {
      embeds: [
        warningEmbed({
          title: `${E('clock')}  ESPERA UN MOMENTO`,
          description: `Podrás crear otro backup en **${remaining}s**.`,
          image: null,
        }),
      ],
      ...EPHEMERAL,
    });
  }

  await interaction.deferReply(EPHEMERAL);

  const backup = await createBackup(interaction.guild, { trigger: 'manual' });
  markCooldown(interaction.guildId);

  await safeEdit(interaction, backupCreatedView(interaction.guild, backup));
}

async function handleBackupsCommand(interaction) {
  await interaction.deferReply(EPHEMERAL);
  const view = await buildBackupListView(interaction.guild);
  await safeEdit(interaction, view);
}

async function handleRestoreCommand(interaction) {
  const codeArg = interaction.options.getString('codigo', true).toUpperCase();
  const mode = interaction.options.getString('modo') ?? null;
  const restoreBans = interaction.options.getBoolean('sanciones') ?? true;

  await interaction.deferReply(EPHEMERAL);

  const backup = await loadBackup(codeArg).catch(() => null);
  if (!backup) {
    return safeEdit(interaction, {
      embeds: [errorEmbed(`No existe ningún backup con el código ${code(codeArg)}.`)],
    });
  }

  await safeEdit(interaction, restoreConfirmView(backup, interaction.guild, { mode, restoreBans }));
}

async function handleCleanCommand(interaction) {
  await interaction.deferReply(EPHEMERAL);
  await safeEdit(interaction, cleanConfirmView(interaction.guild));
}

async function handleRoleCommand(interaction) {
  const role = interaction.options.getRole('rol', true);
  const me = interaction.guild.members.me;

  if (role.id === interaction.guild.id) {
    return safeReply(interaction, {
      embeds: [errorEmbed('No puedes dar el rol **@everyone**.')],
      ...EPHEMERAL,
    });
  }
  if (role.managed) {
    return safeReply(interaction, {
      embeds: [errorEmbed('Ese rol está gestionado por una integración y no se puede asignar manualmente.')],
      ...EPHEMERAL,
    });
  }
  if (role.position >= me.roles.highest.position) {
    return safeReply(interaction, {
      embeds: [
        errorEmbed(
          `El rol **${role.name}** está por encima del rol más alto del bot.\n> Mueve el rol del bot por encima para poder asignarlo.`,
        ),
      ],
      ...EPHEMERAL,
    });
  }

  await interaction.deferReply(EPHEMERAL);
  const members = await interaction.guild.members.fetch();
  const targets = members.filter((member) => !member.user.bot && !member.roles.cache.has(role.id));

  if (!targets.size) {
    return safeEdit(interaction, {
      embeds: [
        infoEmbed({
          title: `${E('check')}  NADA QUE HACER`,
          description: `Todos los miembros ya tienen el rol **${role.name}**.`,
          image: null,
        }),
      ],
    });
  }

  const embed = warningEmbed({
    author: brandAuthor('ASIGNACIÓN MASIVA'),
    title: `${E('users')}  DAR ROL A TODOS`,
    description: [
      `> Se dará el rol **${role.name}** a **${targets.size}** miembro(s).`,
      role.permissions.has(PermissionFlagsBits.Administrator)
        ? `> ${E('warning')} Este rol tiene **Administrador**: los miembros recibirán control total del servidor.`
        : null,
    ].filter(Boolean).join('\n'),
    fields: [
      { name: `${E('users')}  Miembros afectados`, value: code(targets.size), inline: true },
      { name: `${E('star')}  Color`, value: role.hexColor, inline: true },
      { name: `${E('shield')}  Posición`, value: `${role.position}`, inline: true },
    ],
    footer: 'Confirma para comenzar',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`dr:yes:${role.id}`)
      .setLabel('Asignar rol')
      .setEmoji(E('check'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('dr:no')
      .setLabel('Cancelar')
      .setEmoji(E('cross'))
      .setStyle(ButtonStyle.Secondary),
  );

  await safeEdit(interaction, { embeds: [embed], components: [row] });
}

async function handleStatusCommand(interaction) {
  await interaction.deferReply(EPHEMERAL);
  const backups = await listBackups(interaction.guildId);
  const latest = backups[0];

  const embed = brandEmbed({
    color: COLORS.secondary,
    author: brandAuthor('PANEL DE ESTADO'),
    title: `${E('settings')}  ESTADO DEL BOT`,
    thumbnail: guildIcon(interaction.guild),
    description: [
      '> Todos los sistemas operativos.',
      '',
      `${E('shield')}  **${interaction.guild.name}**`,
      small('Los backups se ejecutan automáticamente y se guardan en local.'),
    ].join('\n'),
    fields: [
      { name: `${E('check')}  Estado`, value: 'En línea', inline: true },
      { name: `${E('globe')}  Latencia`, value: `${client.ws.ping} ms`, inline: true },
      { name: `${E('clock')}  Activo desde`, value: fmtDuration(client.uptime ?? 0), inline: true },
      { name: `${E('shield')}  Servidores`, value: code(client.guilds.cache.size), inline: true },
      { name: `${E('backup')}  Backups`, value: code(backups.length), inline: true },
      { name: `${E('settings')}  Memoria`, value: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(0)} MB`, inline: true },
      { name: `${E('restore')}  Automático`, value: `cada ${Math.round(config.backupInterval / 60_000)} min`, inline: true },
      { name: `${E('download')}  Retención`, value: `${config.maxBackupsPerGuild} copias`, inline: true },
      { name: `${E('info')}  Versión`, value: code(`v${BACKUP_VERSION}`), inline: true },
      {
        name: `${E('calendar')}  Último backup`,
        value: latest ? `${code(latest.code)}  ·  ${fmtRelative(latest.timestamp)}` : small('Todavía no hay copias'),
        inline: false,
      },
    ],
    footer: 'Panel de control',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('bk:new')
      .setLabel('Crear backup')
      .setEmoji(E('plus'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('bk:list')
      .setLabel('Ver backups')
      .setEmoji(E('list'))
      .setStyle(ButtonStyle.Secondary),
  );

  await safeEdit(interaction, { embeds: [embed], components: [row] });
}

async function handleHelpCommand(interaction) {
  await interaction.deferReply(EPHEMERAL);

  const embed = brandEmbed({
    color: COLORS.primary,
    author: brandAuthor('CENTRO DE AYUDA'),
    title: `${E('star')}  COMANDOS DISPONIBLES`,
    description: [
      `> ${BRAND} guarda y restaura la configuración completa de tu servidor.`,
      '',
      small('Todos los comandos requieren el permiso Administrador.'),
    ].join('\n'),
    fields: [
      { name: `${E('backup')}  /hacerbackup`, value: small('Copia completa: roles, canales, categorías, permisos, emojis y ajustes.'), inline: false },
      { name: `${E('list')}  /backups`, value: small('Lista, inspecciona, restaura o elimina tus copias de seguridad.'), inline: false },
      { name: `${E('restore')}  /reconstruir`, value: small('Aplica un backup: conservar lo existente o reemplazar el servidor.'), inline: false },
      { name: `${E('users')}  /darrol`, value: small('Asigna un rol a todos los miembros con confirmación previa.'), inline: false },
      { name: `${E('trash')}  /limpiar`, value: small('Vacía canales y roles. Requiere confirmación.'), inline: false },
      { name: `${E('settings')}  /estado`, value: small('Estado del bot, intervalo de backups y última copia.'), inline: false },
    ],
    footer: 'Gestiona todo desde los botones, sin escribir comandos',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('bk:list')
      .setLabel('Abrir gestor de backups')
      .setEmoji(E('list'))
      .setStyle(ButtonStyle.Secondary),
  );

  await safeEdit(interaction, { embeds: [embed], components: [row] });
}

/* ════════════════════════════════════════════════════════════════
   AUTOCOMPLETE
   ════════════════════════════════════════════════════════════════ */

async function handleAutocomplete(interaction) {
  if (interaction.commandName !== 'reconstruir') return;
  const focused = interaction.options.getFocused().toUpperCase();
  const backups = await listBackups();

  const choices = backups
    .filter((backup) => !focused || backup.code.includes(focused) || backup.guildName.toUpperCase().includes(focused))
    .slice(0, 25)
    .map((backup) => ({
      name: `${backup.code} • ${truncate(backup.guildName, 40)} • ${new Date(backup.timestamp).toLocaleDateString('es-ES')}`,
      value: backup.code,
    }));

  await interaction.respond(choices).catch(() => {});
}

/* ════════════════════════════════════════════════════════════════
   BOTONES
   ════════════════════════════════════════════════════════════════ */

async function handleButton(interaction) {
  const [scope, action, ...args] = interaction.customId.split(':');

  if (scope === 'cl') return handleCleanButton(interaction, action);
  if (scope === 'dr') return handleRoleButton(interaction, action, args);
  if (scope !== 'bk') return;

  if (!(await guardAdmin(interaction))) return;

  switch (action) {
    case 'new': return startBackupFromButton(interaction);
    case 'list': return refreshBackupList(interaction);
    case 'select': return;
    case 'detail': return showBackupDetail(interaction, args[0]);
    case 'restore': return showRestoreConfirm(interaction, args[0]);
    case 'do': return runRestore(interaction, args[0], args[1], args[2]);
    case 'delete': return showDeleteConfirm(interaction, args[0]);
    case 'delyes': return confirmDelete(interaction, args[0]);
    case 'cancel': return cancelInteraction(interaction);
    case 'back': return refreshBackupList(interaction);
    default: return undefined;
  }
}

async function startBackupFromButton(interaction) {
  const remaining = checkCooldown(interaction.guildId);
  if (remaining) {
    return safeReply(interaction, {
      embeds: [
        warningEmbed({
          title: `${E('clock')}  ESPERA UN MOMENTO`,
          description: `Podrás crear otro backup en **${remaining}s**.`,
          image: null,
        }),
      ],
      ...EPHEMERAL,
    });
  }

  await interaction.deferReply(EPHEMERAL);
  const backup = await createBackup(interaction.guild, { trigger: 'manual' });
  markCooldown(interaction.guildId);
  await safeEdit(interaction, backupCreatedView(interaction.guild, backup));
}

async function refreshBackupList(interaction) {
  await interaction.deferUpdate().catch(() => {});
  const view = await buildBackupListView(interaction.guild);
  await safeUpdate(interaction, view);
}

async function showBackupDetail(interaction, backupCode) {
  await interaction.deferReply(EPHEMERAL);
  const backup = await loadBackup(backupCode).catch(() => null);
  if (!backup) {
    return safeEdit(interaction, { embeds: [errorEmbed('Ese backup ya no existe.')] });
  }
  await safeEdit(interaction, backupDetailView(backup, { fromList: true }));
}

async function showRestoreConfirm(interaction, backupCode) {
  await interaction.deferReply(EPHEMERAL);
  const backup = await loadBackup(backupCode).catch(() => null);
  if (!backup) {
    return safeEdit(interaction, { embeds: [errorEmbed('Ese backup ya no existe.')] });
  }
  await safeEdit(interaction, restoreConfirmView(backup, interaction.guild));
}

async function showDeleteConfirm(interaction, backupCode) {
  await interaction.deferReply(EPHEMERAL);

  const embed = warningEmbed({
    author: brandAuthor('ELIMINAR BACKUP'),
    title: `${E('trash')}  CONFIRMAR ELIMINACIÓN`,
    description: [
      `> ¿Seguro que quieres eliminar la copia ${code(backupCode)}?`,
      '> Esta acción no se puede deshacer.',
    ].join('\n'),
    image: null,
    footer: 'Confirma para borrar definitivamente',
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`bk:delyes:${backupCode}`)
      .setLabel('Eliminar backup')
      .setEmoji(E('trash'))
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('bk:list')
      .setLabel('Cancelar')
      .setEmoji(E('cross'))
      .setStyle(ButtonStyle.Secondary),
  );

  await safeEdit(interaction, { embeds: [embed], components: [row] });
}

async function confirmDelete(interaction, backupCode) {
  await interaction.deferUpdate().catch(() => {});
  try {
    await deleteBackup(backupCode);
    const embed = successEmbed({
      author: brandAuthor('BACKUP ELIMINADO'),
      title: `${E('trash')}  COPIA BORRADA`,
      description: `La copia ${code(backupCode)} se ha eliminado correctamente.`,
      image: null,
      footer: 'Puedes crear otra cuando quieras',
    });
    await safeUpdate(interaction, { embeds: [embed], components: [] });
  } catch (error) {
    await safeUpdate(interaction, {
      embeds: [errorEmbed(error.message)],
      components: [],
    });
  }
}

async function cancelInteraction(interaction) {
  await interaction.deferUpdate().catch(() => {});
  await safeUpdate(interaction, {
    embeds: [
      infoEmbed({
        title: `${E('cross')}  OPERACIÓN CANCELADA`,
        description: 'No se ha realizado ningún cambio en el servidor.',
        image: null,
        footer: 'Todo sigue igual',
      }),
    ],
    components: [],
  });
}

/* ── Restauración ──────────────────────────────────────────────── */

async function runRestore(interaction, mode, backupCode, bansFlag = '1') {
  const normalizeMode = (value) => (value === 'wipe' ? 'wipe' : 'safe');
  const restoreMode = normalizeMode(mode);
  const restoreBans = bansFlag !== '0';

  await interaction.deferUpdate().catch(() => {});

  const backup = await loadBackup(backupCode).catch(() => null);
  if (!backup) {
    return safeUpdate(interaction, { embeds: [errorEmbed('Ese backup ya no existe.')], components: [] });
  }

  let lastEdit = 0;
  let messageAlive = true;

  const progressPayload = ({ step, total, label }) => ({
    embeds: [
      brandEmbed({
        color: COLORS.secondary,
        author: brandAuthor('RESTAURANDO SERVIDOR'),
        title: `${E('restore')}  APLICANDO LA COPIA DE SEGURIDAD`,
        description: [
          `> Código ${code(backup.code)}  ·  modo **${restoreMode === 'wipe' ? 'reemplazo total' : 'conservar existente'}**`,
          '',
          `${progressBar(Math.max(0, step - 1), total)}`,
          `**${label}**`,
        ].join('\n'),
        footer: 'No cierres este mensaje',
        image: null,
      }),
    ],
    components: [],
  });

  const onProgress = (info) => {
    const now = Date.now();
    if (now - lastEdit < 1200 || !messageAlive) return;
    lastEdit = now;
    safeEdit(interaction, progressPayload(info)).then((ok) => {
      if (!ok) messageAlive = false;
    });
  };

  try {
    const result = await restoreBackup(interaction.guild, backup.code, {
      mode: restoreMode,
      restoreBans,
      onProgress,
    });

    const view = restoreResultView(result);
    const sent = await safeEdit(interaction, view);
    if (!sent) {
      await notifyInDM(
        interaction.user,
        successEmbed({
          author: brandAuthor('RESTAURACIÓN FINALIZADA'),
          title: `${E('check')}  SERVIDOR RESTAURADO`,
          description: `Copia ${code(backup.code)} aplicada en **${interaction.guild.name}**.`,
          fields: [
            { name: `${E('users')} Roles`, value: `${result.rolesCreated} creados / ${result.rolesUpdated} actualizados`, inline: true },
            { name: `${E('chat')} Canales`, value: `${result.channelsCreated} creados / ${result.channelsUpdated} actualizados`, inline: true },
            { name: `${E('lock')} Permisos`, value: `${result.overwritesApplied} aplicados`, inline: true },
            { name: `${E('cross')} Errores`, value: `${result.errors}`, inline: true },
          ],
          footer: 'Enviado por privado porque el canal fue reemplazado',
          image: null,
        }),
      );
    }
  } catch (error) {
    console.error('❌ Error al restaurar:', error);
    const embed = errorEmbed(`No se pudo restaurar el backup.\n> ${truncate(error.message, 600)}`);
    const sent = await safeEdit(interaction, { embeds: [embed], components: [] });
    if (!sent) await notifyInDM(interaction.user, embed);
  }
}

/* ── Limpiar ───────────────────────────────────────────────────── */

async function handleCleanButton(interaction, action) {
  if (!(await guardAdmin(interaction))) return;

  if (action === 'no') {
    return cancelInteraction(interaction);
  }

  if (action === 'yes') {
    await interaction.deferUpdate().catch(() => {});

    const embed = warningEmbed({
      author: brandAuthor('VACIANDO SERVIDOR'),
      title: `${E('trash')}  ELIMINANDO CONTENIDO`,
      description: '> Eliminando canales y roles. Esto puede tardar unos segundos…',
      image: null,
    });
    await safeEdit(interaction, { embeds: [embed], components: [] });

    const guild = interaction.guild;
    let channelsDeleted = 0;
    let rolesDeleted = 0;

    const channels = [...guild.channels.cache.values()].filter((channel) => !channel.isThread());
    const ordered = [
      ...channels.filter((channel) => channel.type !== ChannelType.GuildCategory),
      ...channels.filter((channel) => channel.type === ChannelType.GuildCategory),
    ];

    for (const channel of ordered) {
      try {
        await channel.delete('Limpieza del servidor');
        channelsDeleted++;
        await sleep(250);
      } catch {
        // sin permisos o ya eliminado
      }
    }

    const roles = [...guild.roles.cache.values()]
      .filter((role) => role.id !== guild.id && !role.managed)
      .sort((a, b) => a.position - b.position);

    for (const role of roles) {
      try {
        await role.delete('Limpieza del servidor');
        rolesDeleted++;
        await sleep(250);
      } catch {
        // jerarquía insuficiente
      }
    }

    const result = successEmbed({
      author: brandAuthor('SERVIDOR VACIADO'),
      title: `${E('trash')}  LIMPIEZA COMPLETADA`,
      description: '> Todos los canales y roles se han eliminado.',
      fields: [
        { name: `${E('chat')}  Canales eliminados`, value: code(channelsDeleted), inline: true },
        { name: `${E('users')}  Roles eliminados`, value: code(rolesDeleted), inline: true },
      ],
      footer: 'Puedes restaurar tu backup cuando quieras',
      image: null,
    });

    const sent = await safeEdit(interaction, { embeds: [result], components: [] });
    if (!sent) await notifyInDM(interaction.user, result);
  }
}

/* ── Dar rol ───────────────────────────────────────────────────── */

async function handleRoleButton(interaction, action, args) {
  if (!(await guardAdmin(interaction))) return;

  if (action === 'no') return cancelInteraction(interaction);

  if (action === 'yes') {
    const role = interaction.guild.roles.cache.get(args[0]);
    if (!role) {
      return safeReply(interaction, { embeds: [errorEmbed('Ese rol ya no existe.')], ...EPHEMERAL });
    }

    await interaction.deferUpdate().catch(() => {});

    const members = await interaction.guild.members.fetch();
    const targets = [...members.values()].filter(
      (member) => !member.user.bot && !member.roles.cache.has(role.id),
    );

    let success = 0;
    let failed = 0;
    let lastEdit = 0;

    const renderProgress = () => ({
      embeds: [
        brandEmbed({
          color: COLORS.secondary,
          author: brandAuthor('ASIGNANDO ROL'),
          title: `${E('users')}  DANDO ROL A LOS MIEMBROS`,
          description: [
            `> Rol **${role.name}**`,
            '',
            `${progressBar(success + failed, targets.length)}`,
            `**${success + failed}** de **${targets.length}** procesados`,
          ].join('\n'),
          footer: 'No cierres este mensaje',
          image: null,
        }),
      ],
      components: [],
    });

    await safeEdit(interaction, renderProgress());

    for (const member of targets) {
      try {
        await member.roles.add(role, 'Asignación masiva de rol');
        success++;
      } catch {
        failed++;
      }

      if (Date.now() - lastEdit > 1500) {
        lastEdit = Date.now();
        await safeEdit(interaction, renderProgress());
      }
    }

    const result = successEmbed({
      author: brandAuthor('ASIGNACIÓN FINALIZADA'),
      title: `${E('check')}  ROL ASIGNADO`,
      description: `> El rol **${role.name}** se ha repartido entre los miembros.`,
      fields: [
        { name: `${E('check')}  Asignados`, value: code(success), inline: true },
        { name: `${E('cross')}  Fallidos`, value: code(failed), inline: true },
      ],
      footer: 'Asignación masiva completada',
      image: null,
    });

    await safeEdit(interaction, { embeds: [result], components: [] });
  }
}

/* ════════════════════════════════════════════════════════════════
   MENÚS
   ════════════════════════════════════════════════════════════════ */

async function handleSelectMenu(interaction) {
  if (interaction.customId !== 'bk:select') return;
  if (!(await guardAdmin(interaction))) return;

  const backupCode = interaction.values[0];
  const backup = await loadBackup(backupCode).catch(() => null);

  if (!backup) {
    return safeUpdate(interaction, {
      embeds: [errorEmbed('Ese backup ya no existe.')],
      components: [],
    });
  }

  await safeUpdate(interaction, backupDetailView(backup, { fromList: true }));
}

/* ════════════════════════════════════════════════════════════════
   LOGIN
   ════════════════════════════════════════════════════════════════ */

if (!config.token || !config.clientId) {
  console.error('❌ Faltan DISCORD_TOKEN o CLIENT_ID en el archivo .env');
  process.exit(1);
}

client.login(config.token).catch((error) => {
  console.error('❌ No se pudo iniciar el bot:', error.message);
  process.exit(1);
});

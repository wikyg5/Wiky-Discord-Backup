import { readFileSync, existsSync } from 'fs';
import { writeFile, readdir } from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import config from './config.js';

/* ════════════════════════════════════════════════════════════════
   EMOJIS PERSONALIZADOS
   Se suben una sola vez como emojis de la aplicación y se cachean
   en assets/emojis.json. Si algo falla, se usa el emoji unicode.
   ════════════════════════════════════════════════════════════════ */

const rootDir = path.dirname(fileURLToPath(import.meta.url));
const EMOJI_DIR = path.join(rootDir, 'assets', 'emojis');
const CACHE_FILE = path.join(rootDir, 'assets', 'emojis.json');
const PREFIX = 'lbot_';
// Cambia este número cada vez que se rediseñe el pack: la próxima vez
// que arranque el bot se reemplazan los emojis antiguos automáticamente.
const PACK_VERSION = 2;

const FALLBACKS = {
  shield: '🛡️',
  backup: '📦',
  restore: '♻️',
  trash: '🗑️',
  search: '🔍',
  info: 'ℹ️',
  check: '✅',
  cross: '❌',
  warning: '⚠️',
  key: '🔑',
  folder: '📁',
  chat: '💬',
  tag: '🏷️',
  users: '👥',
  user: '👤',
  calendar: '📅',
  clock: '⏰',
  lock: '🔒',
  settings: '⚙️',
  star: '⭐',
  plus: '➕',
  list: '📋',
  download: '⬇️',
  link: '🔗',
  mail: '📧',
  bell: '🔔',
  tools: '🛠️',
  globe: '🌐',
  card: '💳',
  flag: '🚩',
  staff: '🧑‍💼',
  crown: '👑',
};

let cache = {};
let cacheVersion = 0;

try {
  if (existsSync(CACHE_FILE)) {
    const parsed = JSON.parse(readFileSync(CACHE_FILE, 'utf-8'));
    if (parsed && typeof parsed === 'object') {
      if (parsed.ids && typeof parsed.ids === 'object') {
        cache = parsed.ids;
        cacheVersion = Number(parsed.version ?? 0);
      } else {
        // Formato antiguo: { nombre: id }
        cache = parsed;
      }
    }
  }
} catch {
  cache = {};
}

// Si el pack cambió, no usamos los IDs antiguos: mientras se sube el nuevo
// pack se muestran los emojis unicode de reserva.
if (cacheVersion !== PACK_VERSION) cache = {};

/**
 * Devuelve el emoji personalizado listo para usar en embeds, botones o textos.
 */
export function E(name) {
  const id = cache[name];
  return id ? `<:${PREFIX}${name}:${id}>` : (FALLBACKS[name] ?? '');
}

/**
 * Objeto emoji para menús de selección.
 */
export function emojiOption(name) {
  const id = cache[name];
  return id ? { id, name: `${PREFIX}${name}` } : undefined;
}

export const hasCustomEmoji = (name) => Boolean(cache[name]);
export const emojiCount = () => Object.keys(cache).length;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Sincroniza los PNG de assets/emojis con los emojis de la aplicación.
 * Idempotente: si el pack no cambió, solo crea los que faltan. Si cambió
 * la versión, elimina los antiguos y sube el diseño nuevo.
 */
export async function initEmojis(client) {
  if (!config.customEmojis) return 0;
  if (!client.application) return 0;
  if (!existsSync(EMOJI_DIR)) {
    console.warn('⚠️ No existe assets/emojis; se usarán emojis unicode.');
    return 0;
  }

  let files = [];
  try {
    files = (await readdir(EMOJI_DIR)).filter((file) => file.toLowerCase().endsWith('.png'));
  } catch {
    return 0;
  }
  if (!files.length) return 0;

  let existing;
  try {
    existing = await client.application.emojis.fetch();
  } catch (error) {
    console.warn(`⚠️ No se pudieron leer los emojis de la aplicación: ${error.message}`);
    return Object.keys(cache).length;
  }

  let refreshed = false;

  if (cacheVersion !== PACK_VERSION) {
    const oldEmojis = [...existing.values()].filter((emoji) => emoji.name?.startsWith(PREFIX));
    if (oldEmojis.length) {
      console.log(`♻️ Actualizando el pack de emojis (${oldEmojis.length} antiguos)...`);
    }
    for (const emoji of oldEmojis) {
      try {
        await client.application.emojis.delete(emoji);
        await sleep(120);
      } catch (error) {
        console.warn(`⚠️ No se pudo eliminar el emoji ${emoji.name}: ${error.message}`);
      }
    }
    if (oldEmojis.length) {
      refreshed = true;
      existing = await client.application.emojis.fetch().catch(() => new Map());
    }
  }

  const byName = new Map([...existing.values()].map((emoji) => [emoji.name, emoji]));
  const nextCache = {};
  let created = 0;

  for (const file of files) {
    const base = file.replace(/\.png$/i, '');
    const name = `${PREFIX}${base}`;

    let emoji = byName.get(name);
    if (!emoji) {
      try {
        emoji = await client.application.emojis.create({
          attachment: path.join(EMOJI_DIR, file),
          name,
        });
        created++;
        await sleep(120);
      } catch (error) {
        console.warn(`⚠️ No se pudo crear el emoji ${name}: ${error.message}`);
        continue;
      }
    }

    if (emoji) nextCache[base] = emoji.id;
  }

  cache = nextCache;
  cacheVersion = PACK_VERSION;
  try {
    await writeFile(
      CACHE_FILE,
      JSON.stringify({ version: PACK_VERSION, ids: cache }, null, 2),
      'utf-8',
    );
  } catch (error) {
    console.warn(`⚠️ No se pudo guardar la caché de emojis: ${error.message}`);
  }

  if (created) {
    console.log(`✨ ${created} emoji(s) personalizados ${refreshed ? 'actualizados' : 'creados'} (${Object.keys(cache).length} en total).`);
  } else {
    console.log(`✨ Emojis personalizados listos (${Object.keys(cache).length}).`);
  }

  return Object.keys(cache).length;
}

export { FALLBACKS as emojiFallbacks };

Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $root 'assets\emojis'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

function New-RoundedPath([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
  $path = New-Object System.Drawing.Drawing2D.GraphicsPath
  $d = $r * 2
  $path.AddArc($x, $y, $d, $d, 180, 90)
  $path.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
  $path.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
  $path.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
  $path.CloseFigure()
  return $path
}

$defs = @(
  @{ name = 'shield';   glyph = 0xE83D; color = '#F4F4F5' },
  @{ name = 'backup';   glyph = 0xE74E; color = '#F4F4F5' },
  @{ name = 'restore';  glyph = 0xE72C; color = '#F4F4F5' },
  @{ name = 'trash';    glyph = 0xE74D; color = '#F4F4F5' },
  @{ name = 'search';   glyph = 0xE721; color = '#F4F4F5' },
  @{ name = 'info';     glyph = 0xE946; color = '#F4F4F5' },
  @{ name = 'check';    glyph = 0xE73E; color = '#F4F4F5' },
  @{ name = 'cross';    glyph = 0xE711; color = '#F4F4F5' },
  @{ name = 'warning';  glyph = 0xE7BA; color = '#F4F4F5' },
  @{ name = 'key';      glyph = 0xE8D7; color = '#F4F4F5' },
  @{ name = 'folder';   glyph = 0xE838; color = '#F4F4F5' },
  @{ name = 'chat';     glyph = 0xE8BD; color = '#F4F4F5' },
  @{ name = 'tag';      glyph = 0xE8EC; color = '#F4F4F5' },
  @{ name = 'users';    glyph = 0xE716; color = '#F4F4F5' },
  @{ name = 'user';     glyph = 0xE77B; color = '#F4F4F5' },
  @{ name = 'calendar'; glyph = 0xE787; color = '#F4F4F5' },
  @{ name = 'clock';    glyph = 0xE823; color = '#F4F4F5' },
  @{ name = 'lock';     glyph = 0xE72E; color = '#F4F4F5' },
  @{ name = 'settings'; glyph = 0xE713; color = '#F4F4F5' },
  @{ name = 'star';     glyph = 0xE734; color = '#F4F4F5' },
  @{ name = 'plus';     glyph = 0xE710; color = '#F4F4F5' },
  @{ name = 'list';     glyph = 0xE700; color = '#F4F4F5' },
  @{ name = 'download'; glyph = 0xE896; color = '#F4F4F5' },
  @{ name = 'link';     glyph = 0xE71B; color = '#F4F4F5' },
  @{ name = 'mail';     glyph = 0xE715; color = '#F4F4F5' },
  @{ name = 'bell';     glyph = 0xEA8F; color = '#F4F4F5' },
  @{ name = 'tools';    glyph = 0xE90F; color = '#F4F4F5' },
  @{ name = 'globe';    glyph = 0xE774; color = '#F4F4F5' },
  @{ name = 'card';     glyph = 0xE8C7; color = '#F4F4F5' },
  @{ name = 'flag';     glyph = 0xE7C1; color = '#F4F4F5' },
  @{ name = 'staff';    glyph = 0xE7EE; color = '#F4F4F5' }
)

$size = 128
$iconFont = New-Object System.Drawing.Font('Segoe MDL2 Assets', 78, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
$fmt = New-Object System.Drawing.StringFormat
$fmt.Alignment = [System.Drawing.StringAlignment]::Center
$fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
$fmt.FormatFlags = [System.Drawing.StringFormatFlags]::NoClip

foreach ($d in $defs) {
  $bmp = New-Object System.Drawing.Bitmap $size, $size
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
  $g.Clear([System.Drawing.Color]::Transparent)

  $path = New-RoundedPath 4 4 120 120 30
  $rect = New-Object System.Drawing.RectangleF 4, 4, 120, 120
  $bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, [System.Drawing.Color]::FromArgb(255, 26, 26, 30), [System.Drawing.Color]::FromArgb(255, 6, 6, 7), 90)
  $g.FillPath($bg, $path)

  $border = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(64, 255, 255, 255), 3)
  $g.DrawPath($border, $path)

  $color = [System.Drawing.ColorTranslator]::FromHtml($d.color)
  $glyphBrush = New-Object System.Drawing.SolidBrush $color
  $glyph = [string][char]$d.glyph
  $g.DrawString($glyph, $iconFont, $glyphBrush, (New-Object System.Drawing.RectangleF 0, 0, $size, $size), $fmt)

  $file = Join-Path $outDir ($d.name + '.png')
  $bmp.Save($file, [System.Drawing.Imaging.ImageFormat]::Png)

  $glyphBrush.Dispose(); $border.Dispose(); $bg.Dispose(); $path.Dispose(); $g.Dispose(); $bmp.Dispose()
}

# ── Corona dibujada a mano (no existe en MDL2) ──────────────────
$bmp = New-Object System.Drawing.Bitmap $size, $size
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.Clear([System.Drawing.Color]::Transparent)
$path = New-RoundedPath 4 4 120 120 30
$rect = New-Object System.Drawing.RectangleF 4, 4, 120, 120
$bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, [System.Drawing.Color]::FromArgb(255, 26, 26, 30), [System.Drawing.Color]::FromArgb(255, 6, 6, 7), 90)
$g.FillPath($bg, $path)
$border = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(64, 255, 255, 255), 3)
$g.DrawPath($border, $path)

$crown = New-Object System.Drawing.Drawing2D.GraphicsPath
$crown.AddPolygon(@(
  (New-Object System.Drawing.PointF 27, 98),
  (New-Object System.Drawing.PointF 22, 49),
  (New-Object System.Drawing.PointF 47, 69),
  (New-Object System.Drawing.PointF 64, 37),
  (New-Object System.Drawing.PointF 81, 69),
  (New-Object System.Drawing.PointF 106, 49),
  (New-Object System.Drawing.PointF 101, 98)
))
$crownBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 244, 244, 246))
$g.FillPath($crownBrush, $crown)

$basePath = New-RoundedPath 24 96 80 16 7
$g.FillPath($crownBrush, $basePath)

foreach ($p in @(@(22, 44), @(64, 32), @(106, 44))) {
  $g.FillEllipse($crownBrush, ($p[0] - 4), ($p[1] - 4), 8, 8)
}

$bmp.Save((Join-Path $outDir 'crown.png'), [System.Drawing.Imaging.ImageFormat]::Png)
$crownBrush.Dispose(); $crown.Dispose(); $basePath.Dispose(); $border.Dispose(); $bg.Dispose(); $path.Dispose(); $g.Dispose(); $bmp.Dispose()

# ── Hoja de previsualización ────────────────────────────────────
$files = Get-ChildItem $outDir -Filter *.png | Sort-Object Name
$cols = 8
$tile = 150
$rows = [math]::Ceiling($files.Count / $cols)
$preview = New-Object System.Drawing.Bitmap ($cols * $tile), ($rows * $tile)
$pg = [System.Drawing.Graphics]::FromImage($preview)
$pg.Clear([System.Drawing.Color]::FromArgb(8, 8, 10))
$labelFont = New-Object System.Drawing.Font('Consolas', 9)
$labelBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(170, 190, 180, 205))
for ($i = 0; $i -lt $files.Count; $i++) {
  $col = $i % $cols; $row = [math]::Floor($i / $cols)
  $x = $col * $tile + 11; $y = $row * $tile + 6
  $img = [System.Drawing.Image]::FromFile($files[$i].FullName)
  $pg.DrawImage($img, $x, $y, 128, 128)
  $pg.DrawString([System.IO.Path]::GetFileNameWithoutExtension($files[$i].Name), $labelFont, $labelBrush, ($x + 6), ($y + 130))
  $img.Dispose()
}
$preview.Save((Join-Path $root 'assets\emojis-preview.png'), [System.Drawing.Imaging.ImageFormat]::Png)
$pg.Dispose(); $preview.Dispose()

# ── Banner optimizado para embeds ───────────────────────────────
$src = [System.Drawing.Image]::FromFile((Join-Path $root 'assets\Banner.png'))
$targetW = 1200
$targetH = [int][math]::Round($src.Height * ($targetW / $src.Width))
$banner = New-Object System.Drawing.Bitmap $targetW, $targetH
$bg2 = [System.Drawing.Graphics]::FromImage($banner)
$bg2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$bg2.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
$bg2.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
$bg2.DrawImage($src, 0, 0, $targetW, $targetH)

$encoder = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' }
$params = New-Object System.Drawing.Imaging.EncoderParameters 1
$params.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter ([System.Drawing.Imaging.Encoder]::Quality), 90L
$banner.Save((Join-Path $root 'assets\banner.jpg'), $encoder, $params)
$bg2.Dispose(); $banner.Dispose(); $src.Dispose()

Write-Output "Emojis: $($files.Count)"
Write-Output "Banner: $targetW x $targetH"
Write-Output ((Get-Item (Join-Path $root 'assets\banner.jpg')).Length)

import { writeFile, readFile, mkdir, readdir, unlink, stat } from 'fs/promises';
import { existsSync } from 'fs';
import { ChannelType } from 'discord.js';
import config from './config.js';

/* ════════════════════════════════════════════════════════════════
   SISTEMA DE BACKUPS — captura y restauración de configuración
   ════════════════════════════════════════════════════════════════ */

export const BACKUP_VERSION = 2;
const BACKUP_DIR = config.backupDirectory;
const MAX_BANS = 1000;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const toBigInt = (value, fallback = 0n) => {
  try {
    return BigInt(value ?? 0);
  } catch {
    return fallback;
  }
};

const categoryTypes = new Set([ChannelType.GuildCategory]);
const textTypes = new Set([ChannelType.GuildText, ChannelType.GuildAnnouncement]);
const voiceTypes = new Set([ChannelType.GuildVoice, ChannelType.GuildStageVoice]);
const forumTypes = new Set([ChannelType.GuildForum, ChannelType.GuildMedia]);

const SUPPORTED_CHANNEL_TYPES = new Set([
  ChannelType.GuildText,
  ChannelType.GuildVoice,
  ChannelType.GuildCategory,
  ChannelType.GuildAnnouncement,
  ChannelType.GuildStageVoice,
  ChannelType.GuildForum,
  ChannelType.GuildMedia,
]);

/* ── Utilidades de archivo ─────────────────────────────────────── */

const backupPath = (code) => `${BACKUP_DIR}/${code}.json`;
const sanitizeCode = (code) => String(code ?? '').trim().replace(/[^a-zA-Z0-9_-]/g, '');

export function generateBackupCode(length = 8) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < length; i++) {
    code += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return code;
}

async function createUniqueCode() {
  for (let attempt = 0; attempt < 25; attempt++) {
    const candidate = generateBackupCode();
    if (!existsSync(backupPath(candidate))) return candidate;
  }
  return `${generateBackupCode(6)}${Date.now().toString(36).toUpperCase().slice(-4)}`;
}

/* ── Serialización ─────────────────────────────────────────────── */

function serializeOverwrites(channel) {
  return channel.permissionOverwrites.cache.map((overwrite) => {
    const isRole = overwrite.type === 0;
    const role = isRole ? channel.guild.roles.cache.get(overwrite.id) : null;
    return {
      id: overwrite.id,
      type: isRole ? 0 : 1,
      allow: overwrite.allow.bitfield.toString(),
      deny: overwrite.deny.bitfield.toString(),
      name: isRole
        ? (overwrite.id === channel.guild.id ? '@everyone' : role?.name ?? null)
        : null,
      userId: isRole ? null : overwrite.id,
    };
  });
}

function serializeChannel(channel) {
  const data = {
    id: channel.id,
    name: channel.name,
    type: channel.type,
    position: channel.position ?? 0,
    parentId: channel.parentId ?? null,
    permissionOverwrites: serializeOverwrites(channel),
  };

  if (textTypes.has(channel.type)) {
    data.topic = channel.topic ?? null;
    data.nsfw = Boolean(channel.nsfw);
    data.rateLimitPerUser = channel.rateLimitPerUser ?? 0;
    data.defaultAutoArchiveDuration = channel.defaultAutoArchiveDuration ?? null;
  }

  if (voiceTypes.has(channel.type)) {
    data.bitrate = channel.bitrate ?? null;
    data.userLimit = channel.userLimit ?? 0;
    data.rtcRegion = channel.rtcRegion ?? null;
    if (channel.type === ChannelType.GuildVoice) {
      data.videoQualityMode = channel.videoQualityMode ?? null;
    }
  }

  if (forumTypes.has(channel.type)) {
    data.topic = channel.topic ?? null;
    data.nsfw = Boolean(channel.nsfw);
    data.rateLimitPerUser = channel.rateLimitPerUser ?? 0;
    data.defaultAutoArchiveDuration = channel.defaultAutoArchiveDuration ?? null;
    data.defaultThreadRateLimitPerUser = channel.defaultThreadRateLimitPerUser ?? null;
    data.defaultSortOrder = channel.defaultSortOrder ?? null;
    data.defaultForumLayout = channel.defaultForumLayout ?? null;
    data.defaultReactionEmoji = channel.defaultReactionEmoji
      ? {
          id: channel.defaultReactionEmoji.id ?? null,
          name: channel.defaultReactionEmoji.name ?? null,
        }
      : null;
    data.availableTags = (channel.availableTags ?? []).map((tag) => ({
      name: tag.name,
      moderated: Boolean(tag.moderated),
      emojiId: tag.emojiId ?? null,
      emojiName: tag.emojiName ?? null,
    }));
  }

  return data;
}

function serializeRole(role) {
  return {
    id: role.id,
    name: role.name,
    color: role.color ?? 0,
    colors: role.colors
      ? {
          primaryColor: role.colors.primaryColor ?? 0,
          secondaryColor: role.colors.secondaryColor ?? null,
          tertiaryColor: role.colors.tertiaryColor ?? null,
        }
      : null,
    hoist: Boolean(role.hoist),
    mentionable: Boolean(role.mentionable),
    managed: Boolean(role.managed),
    position: role.position ?? 0,
    permissions: role.permissions.bitfield.toString(),
    unicodeEmoji: role.unicodeEmoji ?? null,
    icon: role.iconURL({ extension: 'png', size: 128 }) ?? null,
    tags: role.tags
      ? {
          botId: role.tags.botId ?? null,
          integrationId: role.tags.integrationId ?? null,
          premiumSubscriber: role.tags.premiumSubscriber ?? false,
          subscriptionListId: role.tags.subscriptionListId ?? null,
          guildConnections: role.tags.guildConnections ?? null,
        }
      : null,
  };
}

function serializeGuild(guild) {
  return {
    name: guild.name,
    description: guild.description ?? null,
    icon: guild.iconURL({ extension: 'png', size: 512 }) ?? null,
    banner: guild.bannerURL({ extension: 'png', size: 1024 }) ?? null,
    splash: guild.splashURL({ extension: 'png', size: 1024 }) ?? null,
    verificationLevel: guild.verificationLevel,
    defaultMessageNotifications: guild.defaultMessageNotifications,
    explicitContentFilter: guild.explicitContentFilter,
    afkChannelId: guild.afkChannelId ?? null,
    afkTimeout: guild.afkTimeout ?? 300,
    systemChannelId: guild.systemChannelId ?? null,
    systemChannelFlags: guild.systemChannelFlags?.bitfield?.toString() ?? '0',
    rulesChannelId: guild.rulesChannelId ?? null,
    publicUpdatesChannelId: guild.publicUpdatesChannelId ?? null,
    preferredLocale: guild.preferredLocale ?? null,
    mfaLevel: guild.mfaLevel ?? 0,
    premiumTier: guild.premiumTier ?? 0,
    premiumProgressBarEnabled: Boolean(guild.premiumProgressBarEnabled),
    features: guild.features ?? [],
    ownerId: guild.ownerId ?? null,
    memberCount: guild.memberCount ?? 0,
  };
}

/* ── Crear backup ──────────────────────────────────────────────── */

function fingerprintOf(payload) {
  return JSON.stringify({
    guild: payload.guild,
    everyonePermissions: payload.everyonePermissions,
    roles: payload.roles,
    categories: payload.categories,
    channels: payload.channels,
    emojis: payload.emojis,
  });
}

async function latestFingerprints(guildId, limit = 3) {
  if (!existsSync(BACKUP_DIR)) return [];
  const files = (await readdir(BACKUP_DIR)).filter((file) => file.endsWith('.json'));
  const entries = [];

  for (const file of files) {
    try {
      const raw = JSON.parse(await readFile(`${BACKUP_DIR}/${file}`, 'utf-8'));
      const id = raw.guildId ?? raw.id;
      if (id !== guildId) continue;
      entries.push({
        fingerprint: raw.fingerprint ?? null,
        timestamp: raw.timestamp ?? 0,
      });
    } catch {
      // archivo corrupto o backup ajeno: se ignora
    }
  }

  return entries
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit)
    .map((entry) => entry.fingerprint);
}

/**
 * Crea un snapshot completo del servidor. NO modifica el servidor.
 */
export async function createBackup(guild, { trigger = 'manual', includeBans = true, skipIfUnchanged = false } = {}) {
  console.log(`📦 Creando backup de ${guild.name} (${trigger})...`);

  const roles = [...guild.roles.cache.values()]
    .filter((role) => role.id !== guild.id && role.name !== '@everyone')
    .sort((a, b) => a.position - b.position)
    .map(serializeRole);

  const allChannels = [...guild.channels.cache.values()]
    .filter((channel) => !channel.isThread?.() && SUPPORTED_CHANNEL_TYPES.has(channel.type))
    .sort((a, b) => (a.position ?? 0) - (b.position ?? 0));

  const categories = allChannels.filter((channel) => categoryTypes.has(channel.type)).map(serializeChannel);
  const channels = allChannels.filter((channel) => !categoryTypes.has(channel.type)).map(serializeChannel);

  const emojis = [...guild.emojis.cache.values()].map((emoji) => ({
    id: emoji.id,
    name: emoji.name,
    animated: Boolean(emoji.animated),
    url: emoji.imageURL({ extension: emoji.animated ? 'gif' : 'png', size: 64 }),
  }));

  let bans = [];
  if (includeBans) {
    try {
      const fetched = await guild.bans.fetch({ limit: MAX_BANS });
      bans = [...fetched.values()].slice(0, MAX_BANS).map((ban) => ({
        userId: ban.user.id,
        tag: ban.user.tag ?? ban.user.username,
        reason: ban.reason ?? null,
      }));
    } catch (error) {
      console.warn(`⚠️ No se pudieron leer los bans de ${guild.name}: ${error.message}`);
    }
  }

  const payload = {
    guild: serializeGuild(guild),
    everyonePermissions: guild.roles.everyone.permissions.bitfield.toString(),
    roles,
    categories,
    channels,
    emojis,
    bans,
  };

  const fingerprint = fingerprintOf(payload);

  if (skipIfUnchanged) {
    const previous = await latestFingerprints(guild.id, 2);
    if (previous.includes(fingerprint)) {
      console.log(`⏭️ ${guild.name} no ha cambiado, se omite el backup automático.`);
      return { skipped: true, guildId: guild.id, guildName: guild.name };
    }
  }

  const overwriteCount =
    categories.reduce((total, channel) => total + channel.permissionOverwrites.length, 0) +
    channels.reduce((total, channel) => total + channel.permissionOverwrites.length, 0);

  const code = await createUniqueCode();
  const timestamp = Date.now();

  const backup = {
    version: BACKUP_VERSION,
    code,
    trigger,
    guildId: guild.id,
    guildName: guild.name,
    guildIcon: payload.guild.icon,
    timestamp,
    fingerprint,
    ...payload,
    stats: {
      channels: channels.length,
      categories: categories.length,
      roles: roles.length,
      emojis: emojis.length,
      bans: bans.length,
      permissionOverwrites: overwriteCount,
    },
  };

  await mkdir(BACKUP_DIR, { recursive: true });
  await writeFile(backupPath(code), JSON.stringify(backup, null, 2), 'utf-8');

  console.log(`✅ Backup ${code} guardado (${channels.length} canales, ${categories.length} categorías, ${roles.length} roles).`);

  if (trigger === 'auto') {
    await pruneBackups(guild.id, config.maxBackupsPerGuild);
  }

  return backup;
}

/* ── Listar / leer / eliminar ──────────────────────────────────── */

function normalizeBackup(raw, fileCode) {
  const guild = raw.guild ?? {};
  const categories = Array.isArray(raw.categories) ? raw.categories : [];
  const channels = Array.isArray(raw.channels) ? raw.channels : [];
  const roles = Array.isArray(raw.roles) ? raw.roles : [];

  return {
    ...raw,
    version: raw.version ?? 1,
    code: raw.code ?? fileCode,
    trigger: raw.trigger ?? 'manual',
    guildId: raw.guildId ?? raw.id ?? guild.id ?? null,
    guildName: raw.guildName ?? raw.name ?? guild.name ?? 'Servidor desconocido',
    timestamp: raw.timestamp ?? Date.now(),
    guild: raw.guild ?? null,
    everyonePermissions: raw.everyonePermissions ?? null,
    roles,
    categories,
    channels,
    emojis: Array.isArray(raw.emojis) ? raw.emojis : [],
    bans: Array.isArray(raw.bans) ? raw.bans : [],
  };
}

export async function loadBackup(code) {
  const safe = sanitizeCode(code).toUpperCase();
  if (!safe) throw new Error('Código de backup inválido.');

  let file = backupPath(safe);
  if (!existsSync(file)) {
    // Compatibilidad con nombres de archivo antiguos
    if (!existsSync(BACKUP_DIR)) throw new Error('No existe ningún backup con ese código.');
    const files = await readdir(BACKUP_DIR);
    const match = files.find(
      (name) => name.endsWith('.json') && name.slice(0, -5).toUpperCase() === safe,
    );
    if (!match) throw new Error('No existe ningún backup con ese código.');
    file = `${BACKUP_DIR}/${match}`;
  }

  const raw = JSON.parse(await readFile(file, 'utf-8'));
  return normalizeBackup(raw, safe);
}

export async function backupExists(code) {
  try {
    await loadBackup(code);
    return true;
  } catch {
    return false;
  }
}

export async function listBackups(guildId = null) {
  if (!existsSync(BACKUP_DIR)) return [];

  const files = (await readdir(BACKUP_DIR)).filter((file) => file.endsWith('.json'));
  const backups = [];

  for (const file of files) {
    try {
      const path = `${BACKUP_DIR}/${file}`;
      const [data, info] = await Promise.all([readFile(path, 'utf-8'), stat(path)]);
      const raw = JSON.parse(data);
      const backup = normalizeBackup(raw, file.slice(0, -5));

      if (guildId && backup.guildId !== guildId) continue;

      const overwrites =
        backup.stats?.permissionOverwrites ??
        backup.categories.reduce((total, channel) => total + (channel.permissionOverwrites?.length ?? 0), 0) +
          backup.channels.reduce((total, channel) => total + (channel.permissionOverwrites?.length ?? 0), 0);

      backups.push({
        code: backup.code,
        fileName: file,
        guildId: backup.guildId,
        guildName: backup.guildName,
        guildIcon: raw.guildIcon ?? raw.guild?.icon ?? null,
        timestamp: backup.timestamp,
        trigger: backup.trigger,
        version: backup.version,
        channels: backup.channels.length,
        categories: backup.categories.length,
        roles: backup.roles.length,
        emojis: backup.emojis.length,
        bans: backup.bans.length,
        permissionOverwrites: overwrites,
        hasSettings: Boolean(backup.guild),
        size: info.size,
      });
    } catch (error) {
      console.error(`⚠️ No se pudo leer el backup ${file}: ${error.message}`);
    }
  }

  return backups.sort((a, b) => b.timestamp - a.timestamp);
}

export async function deleteBackup(code) {
  const safe = sanitizeCode(code).toUpperCase();
  if (!safe) throw new Error('Código de backup inválido.');

  let file = backupPath(safe);
  if (!existsSync(file)) {
    if (!existsSync(BACKUP_DIR)) throw new Error('No existe ningún backup con ese código.');
    const files = await readdir(BACKUP_DIR);
    const match = files.find(
      (name) => name.endsWith('.json') && name.slice(0, -5).toUpperCase() === safe,
    );
    if (!match) throw new Error('No existe ningún backup con ese código.');
    file = `${BACKUP_DIR}/${match}`;
  }

  await unlink(file);
  console.log(`🗑️ Backup ${safe} eliminado.`);
}

/**
 * Mantiene solamente los N backups automáticos más recientes.
 * Los backups manuales nunca se borran solos.
 */
export async function pruneBackups(guildId, keep = config.maxBackupsPerGuild) {
  const backups = (await listBackups(guildId)).filter((backup) => backup.trigger === 'auto');
  const excess = backups.slice(Math.max(0, keep));
  for (const backup of excess) {
    try {
      await deleteBackup(backup.code);
    } catch (error) {
      console.error(`⚠️ No se pudo podar el backup ${backup.code}: ${error.message}`);
    }
  }
  return excess.length;
}

/* ── Restaurar ─────────────────────────────────────────────────── */

const KEYS = {
  afkTimeout: [60, 300, 900, 1800, 3600],
};

export async function restoreBackup(guild, code, options = {}) {
  const {
    mode = 'safe',
    restoreBans = true,
    onProgress = () => {},
  } = options;

  const backup = await loadBackup(code);
  const start = Date.now();
  const wipe = mode === 'wipe';

  const result = {
    mode,
    backup: { code: backup.code, guildName: backup.guildName, timestamp: backup.timestamp },
    rolesCreated: 0,
    rolesUpdated: 0,
    rolesDeleted: 0,
    categoriesCreated: 0,
    categoriesUpdated: 0,
    channelsCreated: 0,
    channelsUpdated: 0,
    channelsDeleted: 0,
    overwritesApplied: 0,
    emojisCreated: 0,
    bansRestored: 0,
    settingsApplied: 0,
    errors: 0,
    errorDetails: [],
    warnings: [],
    durationMs: 0,
  };

  const warn = (message) => {
    if (result.warnings.length < 25) result.warnings.push(message);
  };
  const fail = (message, error) => {
    result.errors++;
    if (result.errorDetails.length < 25) {
      result.errorDetails.push(`${message}: ${error?.message ?? error}`);
    }
    console.error(`❌ ${message}:`, error?.message ?? error);
  };

  const steps = wipe ? 9 : 8;
  let step = 0;
  const report = (label) => {
    step++;
    try {
      onProgress({ step, total: steps, label });
    } catch {
      // el reporter nunca debe romper la restauración
    }
  };

  if (!guild.members.me?.permissions.has('Administrator')) {
    throw new Error('El bot necesita el permiso **Administrador** para restaurar un backup.');
  }

  /* ── 1. Limpieza opcional ────────────────────────────────────── */
  if (wipe) {
    report('Eliminando canales y roles actuales...');
    const currentChannels = [...guild.channels.cache.values()].filter((channel) => !channel.isThread());
    const ordered = [
      ...currentChannels.filter((channel) => channel.type !== ChannelType.GuildCategory),
      ...currentChannels.filter((channel) => channel.type === ChannelType.GuildCategory),
    ];
    for (const channel of ordered) {
      try {
        await channel.delete('Restauración de backup (modo reemplazo)');
        result.channelsDeleted++;
        await sleep(120);
      } catch (error) {
        warn(`No se pudo eliminar el canal #${channel.name}.`);
      }
    }

    const currentRoles = [...guild.roles.cache.values()]
      .filter((role) => role.id !== guild.id && !role.managed)
      .sort((a, b) => a.position - b.position);
    for (const role of currentRoles) {
      try {
        await role.delete('Restauración de backup (modo reemplazo)');
        result.rolesDeleted++;
        await sleep(120);
      } catch {
        warn(`No se pudo eliminar el rol ${role.name}.`);
      }
    }
  }

  /* ── 2. @everyone ────────────────────────────────────────────── */
  try {
    const everyonePermissions = backup.everyonePermissions ?? backup.roles.find((role) => role.name === '@everyone')?.permissions;
    if (everyonePermissions) {
      await guild.roles.everyone.setPermissions(toBigInt(everyonePermissions), 'Restauración de backup');
      result.settingsApplied++;
    }
  } catch (error) {
    fail('No se pudieron aplicar los permisos de @everyone', error);
  }

  /* ── 3. Roles ───────────────────────────────────────────────── */
  report('Restaurando roles y sus permisos...');

  const roleMap = new Map(); // oldId -> newId
  const roleNameMap = new Map(); // lowercase name -> role

  const rolesAsc = [...backup.roles]
    .filter((role) => role.name !== '@everyone')
    .sort((a, b) => (a.position ?? 0) - (b.position ?? 0));

  for (const roleData of rolesAsc) {
    const key = String(roleData.name ?? '').toLowerCase();
    if (roleData.managed) {
      const managed = guild.roles.cache.find((role) => role.name === roleData.name);
      if (managed) {
        roleMap.set(roleData.id, managed.id);
        roleNameMap.set(key, managed);
      }
      continue;
    }

    let role = roleData.id ? guild.roles.cache.get(roleData.id) : null;
    if (!role) role = guild.roles.cache.find((candidate) => candidate.id !== guild.id && candidate.name === roleData.name);
    if (!roleData.name) continue;

    const primaryColor = roleData.colors?.primaryColor ?? roleData.color ?? 0;
    const roleOptions = {
      name: roleData.name,
      permissions: toBigInt(roleData.permissions),
      hoist: Boolean(roleData.hoist),
      mentionable: Boolean(roleData.mentionable),
      colors: { primaryColor },
    };

    if (roleData.colors?.secondaryColor) roleOptions.colors.secondaryColor = roleData.colors.secondaryColor;
    if (roleData.colors?.tertiaryColor) roleOptions.colors.tertiaryColor = roleData.colors.tertiaryColor;

    try {
      if (role) {
        await role.edit({
          ...roleOptions,
          icon: roleData.icon ?? undefined,
          unicodeEmoji: roleData.unicodeEmoji ?? undefined,
        }, 'Restauración de backup');
        result.rolesUpdated++;
      } else {
        role = await guild.roles.create({
          ...roleOptions,
          reason: 'Restauración de backup',
        });
        roleMap.set(roleData.id, role.id);
        result.rolesCreated++;

        if (roleData.icon || roleData.unicodeEmoji) {
          try {
            await role.edit({
              icon: roleData.icon ?? null,
              unicodeEmoji: roleData.unicodeEmoji ?? null,
            }, 'Restauración de backup');
          } catch {
            warn(`No se pudo aplicar el icono del rol ${roleData.name}.`);
          }
        }
        await sleep(200);
      }

      roleMap.set(roleData.id, role.id);
      roleNameMap.set(key, role);
    } catch (error) {
      fail(`No se pudo restaurar el rol ${roleData.name}`, error);
      if (role) roleNameMap.set(key, role);
    }
  }

  // Jerarquía de roles
  try {
    const positionPayload = [];
    const highestPosition = guild.members.me?.roles?.highest?.position ?? Number.MAX_SAFE_INTEGER;
    for (const roleData of rolesAsc) {
      const role = roleMap.has(roleData.id) ? guild.roles.cache.get(roleMap.get(roleData.id)) : roleNameMap.get(String(roleData.name ?? '').toLowerCase());
      if (!role || role.managed || role.position >= highestPosition) continue;
      positionPayload.push({ role, position: Math.min(roleData.position ?? role.position, highestPosition - 1) });
    }
    if (positionPayload.length) {
      await guild.roles.setPositions(positionPayload.sort((a, b) => a.position - b.position), 'Restauración de backup');
    }
  } catch (error) {
    warn('No se pudo aplicar el orden jerárquico de todos los roles.');
  }

  /* ── 4. Resolución de permisos ──────────────────────────────── */
  const resolveOverwrites = async (overwrites = []) => {
    const resolved = [];
    for (const overwrite of overwrites) {
      const type = Number(overwrite.type) === 1 ? 1 : 0;
      let targetId = null;

      if (type === 0) {
        if (overwrite.id === backup.guildId || overwrite.name === '@everyone') {
          targetId = guild.id;
        } else {
          targetId = roleMap.get(overwrite.id)
            ?? roleNameMap.get(String(overwrite.name ?? '').toLowerCase())?.id
            ?? (guild.roles.cache.has(overwrite.id) ? overwrite.id : null);
        }
      } else {
        const memberId = overwrite.userId ?? overwrite.id;
        if (guild.id === backup.guildId) {
          // En el mismo servidor el ID del miembro sigue siendo válido
          targetId = memberId;
        } else if (guild.members.cache.has(memberId)) {
          targetId = memberId;
        } else {
          // Servidor distinto: comprobamos si el miembro está presente
          const member = await guild.members.fetch(memberId).catch(() => null);
          targetId = member?.id ?? null;
        }
        if (!targetId) warn('Se omitió un permiso individual de un miembro que no está en el servidor.');
      }

      if (!targetId) {
        if (type === 0) warn(`No se pudo emparejar un rol para el permiso de un canal (${overwrite.name ?? overwrite.id}).`);
        continue;
      }

      resolved.push({
        id: targetId,
        type,
        allow: toBigInt(overwrite.allow),
        deny: toBigInt(overwrite.deny),
      });
    }
    return resolved;
  };

  /* ── 5. Categorías ─────────────────────────────────────────── */
  report('Restaurando categorías...');
  const categoryMap = new Map(); // oldId -> new category

  for (const categoryData of backup.categories) {
    try {
      let category = (categoryData.id && guild.channels.cache.get(categoryData.id))
        || guild.channels.cache.find(
          (channel) => channel.type === ChannelType.GuildCategory && channel.name === categoryData.name,
        );

      if (!category) {
        category = await guild.channels.create({
          name: categoryData.name,
          type: ChannelType.GuildCategory,
          reason: 'Restauración de backup',
        });
        result.categoriesCreated++;
        await sleep(150);
      } else {
        result.categoriesUpdated++;
      }

      const overwrites = await resolveOverwrites(categoryData.permissionOverwrites);
      if (overwrites.length) {
        await category.permissionOverwrites.set(overwrites, 'Restauración de backup');
        result.overwritesApplied += overwrites.length;
      }

      categoryMap.set(categoryData.id, category);
    } catch (error) {
      fail(`No se pudo restaurar la categoría ${categoryData.name}`, error);
    }
  }

  /* ── 6. Canales ────────────────────────────────────────────── */
  report('Restaurando canales y sus permisos...');
  const channelMap = new Map(); // oldId -> new channel

  const channelsAsc = [...backup.channels].sort((a, b) => (a.position ?? 0) - (b.position ?? 0));

  for (const channelData of channelsAsc) {
    try {
      const parent = channelData.parentId
        ? categoryMap.get(channelData.parentId)
          ?? guild.channels.cache.get(channelData.parentId)
          ?? null
        : null;

      let channel = (channelData.id && guild.channels.cache.get(channelData.id))
        || guild.channels.cache.find(
          (candidate) => candidate.type === channelData.type && candidate.name === channelData.name,
        );

      const createOptions = {
        name: channelData.name,
        type: channelData.type,
        reason: 'Restauración de backup',
      };

      if (parent && channelData.type !== ChannelType.GuildCategory) {
        createOptions.parent = parent.id;
      }

      if (textTypes.has(channelData.type)) {
        createOptions.topic = channelData.topic ?? null;
        createOptions.nsfw = Boolean(channelData.nsfw);
        createOptions.rateLimitPerUser = channelData.rateLimitPerUser ?? 0;
        if (channelData.defaultAutoArchiveDuration) {
          createOptions.defaultAutoArchiveDuration = channelData.defaultAutoArchiveDuration;
        }
      }

      if (voiceTypes.has(channelData.type)) {
        if (channelData.bitrate) createOptions.bitrate = channelData.bitrate;
        createOptions.userLimit = channelData.userLimit ?? 0;
        if (channelData.rtcRegion) createOptions.rtcRegion = channelData.rtcRegion;
        if (channelData.videoQualityMode) createOptions.videoQualityMode = channelData.videoQualityMode;
      }

      if (forumTypes.has(channelData.type)) {
        createOptions.topic = channelData.topic ?? null;
        createOptions.nsfw = Boolean(channelData.nsfw);
        createOptions.rateLimitPerUser = channelData.rateLimitPerUser ?? 0;
        if (channelData.defaultAutoArchiveDuration) {
          createOptions.defaultAutoArchiveDuration = channelData.defaultAutoArchiveDuration;
        }
        if (channelData.defaultThreadRateLimitPerUser != null) {
          createOptions.defaultThreadRateLimitPerUser = channelData.defaultThreadRateLimitPerUser;
        }
        if (channelData.defaultSortOrder != null) {
          createOptions.defaultSortOrder = channelData.defaultSortOrder;
        }
        if (channelData.defaultForumLayout != null) {
          createOptions.defaultForumLayout = channelData.defaultForumLayout;
        }
      }

      if (channel) {
        result.channelsUpdated++;
        const editPayload = {
          ...(channelData.topic !== undefined ? { topic: channelData.topic } : {}),
          ...(channelData.nsfw !== undefined ? { nsfw: channelData.nsfw } : {}),
          ...(channelData.rateLimitPerUser !== undefined ? { rateLimitPerUser: channelData.rateLimitPerUser } : {}),
          ...(channelData.bitrate ? { bitrate: channelData.bitrate } : {}),
          ...(channelData.userLimit !== undefined ? { userLimit: channelData.userLimit } : {}),
          ...(channelData.rtcRegion !== undefined ? { rtcRegion: channelData.rtcRegion } : {}),
          ...(channelData.videoQualityMode ? { videoQualityMode: channelData.videoQualityMode } : {}),
          reason: 'Restauración de backup',
        };
        if (channelData.type !== ChannelType.GuildCategory) {
          editPayload.parent = parent?.id ?? null;
        }
        await channel.edit(editPayload).catch((error) => {
          warn(`No se pudo actualizar la configuración de #${channelData.name}.`);
        });
      } else {
        channel = await guild.channels.create(createOptions);
        result.channelsCreated++;
        await sleep(150);
      }

      const overwrites = await resolveOverwrites(channelData.permissionOverwrites);
      if (overwrites.length) {
        await channel.permissionOverwrites.set(overwrites, 'Restauración de backup');
        result.overwritesApplied += overwrites.length;
      }

      // Extras de foros que no se pueden pasar al crear
      if (forumTypes.has(channelData.type) && typeof channel.setAvailableTags === 'function') {
        if (channelData.availableTags?.length) {
          const tags = channelData.availableTags.map((tag) => {
            const cachedEmoji = tag.emojiId ? guild.emojis.cache.get(tag.emojiId) : null;
            return {
              name: tag.name,
              moderated: Boolean(tag.moderated),
              emoji: cachedEmoji
                ? { id: cachedEmoji.id, name: cachedEmoji.name ?? undefined }
                : tag.emojiName
                  ? { name: tag.emojiName }
                  : undefined,
            };
          });
          try {
            await channel.setAvailableTags(tags, 'Restauración de backup');
          } catch {
            warn(`No se pudieron restaurar las etiquetas del foro #${channelData.name}.`);
          }
        }
        if (channelData.defaultReactionEmoji?.id || channelData.defaultReactionEmoji?.name) {
          try {
            await channel.setDefaultReactionEmoji(channelData.defaultReactionEmoji, 'Restauración de backup');
          } catch {
            warn(`No se pudo restaurar la reacción por defecto de #${channelData.name}.`);
          }
        }
      }

      channelMap.set(channelData.id, channel);
    } catch (error) {
      fail(`No se pudo restaurar el canal ${channelData.name}`, error);
    }
  }

  /* ── 7. Posiciones ─────────────────────────────────────────── */
  report('Aplicando el orden de canales...');
  const positionGroups = [
    [...backup.categories].sort((a, b) => (a.position ?? 0) - (b.position ?? 0)),
    [...backup.channels].sort((a, b) => (a.position ?? 0) - (b.position ?? 0)),
  ];
  for (const group of positionGroups) {
    for (const data of group) {
      const channel = categoryMap.get(data.id) ?? channelMap.get(data.id);
      if (!channel) continue;
      try {
        await channel.setPosition(data.position ?? channel.position, { reason: 'Restauración de backup' });
      } catch {
        // el orden es estético: no se considera un fallo crítico
      }
    }
  }

  /* ── 8. Emojis ─────────────────────────────────────────────── */
  report('Restaurando emojis...');
  for (const emoji of backup.emojis) {
    if (!emoji?.name || !emoji?.url) continue;
    const exists = guild.emojis.cache.find(
      (candidate) => candidate.name === emoji.name && candidate.animated === emoji.animated,
    );
    if (exists) continue;
    try {
      await guild.emojis.create({
        attachment: emoji.url,
        name: emoji.name,
        reason: 'Restauración de backup',
      });
      result.emojisCreated++;
      await sleep(250);
    } catch (error) {
      warn(`No se pudo crear el emoji ${emoji.name}.`);
    }
  }

  /* ── 9. Ajustes del servidor ───────────────────────────────── */
  report('Aplicando configuración del servidor...');
  const settings = backup.guild;
  if (settings) {
    const trySetting = async (label, fn) => {
      try {
        await fn();
        result.settingsApplied++;
      } catch {
        warn(`No se pudo aplicar el ajuste: ${label}.`);
      }
    };

    if (wipe) {
      if (settings.name) await trySetting('nombre del servidor', () => guild.setName(settings.name, 'Restauración de backup'));
      if (settings.icon) await trySetting('icono del servidor', () => guild.setIcon(settings.icon, 'Restauración de backup'));
      if (settings.banner) await trySetting('banner del servidor', () => guild.setBanner(settings.banner, 'Restauración de backup'));
      if (settings.description) await trySetting('descripción del servidor', () => guild.setDescription(settings.description, 'Restauración de backup'));
    }

    if (settings.verificationLevel != null) {
      await trySetting('nivel de verificación', () => guild.setVerificationLevel(settings.verificationLevel, 'Restauración de backup'));
    }
    if (settings.defaultMessageNotifications != null) {
      await trySetting('notificaciones por defecto', () => guild.setDefaultMessageNotifications(settings.defaultMessageNotifications, 'Restauración de backup'));
    }
    if (settings.explicitContentFilter != null) {
      await trySetting('filtro de contenido', () => guild.setExplicitContentFilter(settings.explicitContentFilter, 'Restauración de backup'));
    }
    if (settings.preferredLocale) {
      await trySetting('idioma preferido', () => guild.setPreferredLocale(settings.preferredLocale, 'Restauración de backup'));
    }
    if (settings.systemChannelFlags != null) {
      await trySetting('ajustes del canal del sistema', () => guild.setSystemChannelFlags(toBigInt(settings.systemChannelFlags), 'Restauración de backup'));
    }

    const afkChannel = settings.afkChannelId ? channelMap.get(settings.afkChannelId) : null;
    const systemChannel = settings.systemChannelId
      ? channelMap.get(settings.systemChannelId) ?? guild.channels.cache.get(settings.systemChannelId)
      : null;
    const rulesChannel = settings.rulesChannelId
      ? channelMap.get(settings.rulesChannelId) ?? guild.channels.cache.get(settings.rulesChannelId)
      : null;
    const updatesChannel = settings.publicUpdatesChannelId
      ? channelMap.get(settings.publicUpdatesChannelId) ?? guild.channels.cache.get(settings.publicUpdatesChannelId)
      : null;

    if (afkChannel) {
      const timeout = KEYS.afkTimeout.includes(settings.afkTimeout) ? settings.afkTimeout : 300;
      await trySetting('canal AFK', () => guild.setAFKChannel(afkChannel, timeout, 'Restauración de backup'));
    }
    if (systemChannel) {
      await trySetting('canal del sistema', () => guild.setSystemChannel(systemChannel, 'Restauración de backup'));
    }
    if (rulesChannel) {
      await trySetting('canal de reglas', () => guild.setRulesChannel(rulesChannel, 'Restauración de backup'));
    }
    if (updatesChannel) {
      await trySetting('canal de anuncios', () => guild.setPublicUpdatesChannel(updatesChannel, 'Restauración de backup'));
    }
  }

  /* ── 10. Bans ──────────────────────────────────────────────── */
  if (restoreBans && backup.bans?.length) {
    try {
      const existing = await guild.bans.fetch();
      for (const ban of backup.bans) {
        if (!ban?.userId || existing.has(ban.userId)) continue;
        try {
          await guild.members.ban(ban.userId, {
            reason: ban.reason ? `Restauración de backup: ${ban.reason}` : 'Restauración de backup',
          });
          result.bansRestored++;
          await sleep(120);
        } catch {
          warn('No se pudo restaurar una de las expulsiones.');
        }
      }
    } catch {
      warn('No se pudo leer la lista de expulsiones.');
    }
  }

  result.durationMs = Date.now() - start;
  console.log(`✅ Backup ${backup.code} restaurado en ${guild.name} (${result.durationMs} ms).`);
  return result;
}

/* ── Backups automáticos ───────────────────────────────────────── */

let autoBackupTimer = null;
let autoBackupRunning = false;

export async function runBackupCycle(client, { trigger = 'auto' } = {}) {
  if (autoBackupRunning) return [];
  autoBackupRunning = true;
  const results = [];

  try {
    for (const guild of client.guilds.cache.values()) {
      try {
        const backup = await createBackup(guild, {
          trigger,
          skipIfUnchanged: trigger === 'auto',
        });
        results.push({ guildId: guild.id, guildName: guild.name, backup });
      } catch (error) {
        console.error(`❌ Error al respaldar ${guild.name}: ${error.message}`);
        results.push({ guildId: guild.id, guildName: guild.name, error });
      }
    }
  } finally {
    autoBackupRunning = false;
  }

  return results;
}

export function startAutoBackup(client) {
  if (autoBackupTimer) clearInterval(autoBackupTimer);

  const tick = async () => {
    const results = await runBackupCycle(client);
    const created = results.filter((entry) => entry.backup && !entry.backup.skipped);

    if (created.length && config.backupLogChannelId) {
      try {
        const channel = await client.channels.fetch(config.backupLogChannelId).catch(() => null);
        if (channel?.isTextBased()) {
          const { brandEmbed, COLORS } = await import('./theme.js');
          const { E } = await import('./emojis.js');
          const embed = brandEmbed({
            color: COLORS.success,
            title: `${E('shield')}  BACKUP AUTOMÁTICO`,
            description: `Se han guardado **${created.length}** backup(s).`,
            fields: created.slice(0, 5).map((entry) => ({
              name: `${E('backup')} ${entry.guildName}`,
              value: `Código: \`${entry.backup.code}\` • ${entry.backup.stats.channels} canales • ${entry.backup.stats.roles} roles`,
            })),
            footer: 'Sistema automático',
            image: null,
          });
          await channel.send({ embeds: [embed] });
        }
      } catch (error) {
        console.warn(`⚠️ No se pudo publicar el log de backup: ${error.message}`);
      }
    }
  };

  const firstRun = setTimeout(() => {
    tick().catch((error) => console.error('❌ Error en el ciclo de backups:', error));
  }, 15_000);

  autoBackupTimer = setInterval(() => {
    tick().catch((error) => console.error('❌ Error en el ciclo de backups:', error));
  }, Math.max(60_000, config.backupInterval));

  // No mantenemos vivo el proceso solo por el temporizador
  firstRun.unref?.();
  autoBackupTimer.unref?.();

  console.log(
    `🔄 Backups automáticos activos cada ${Math.round(config.backupInterval / 60_000)} min (retención: ${config.maxBackupsPerGuild} por servidor).`,
  );

  return () => stopAutoBackup();
}

export function stopAutoBackup() {
  if (autoBackupTimer) {
    clearInterval(autoBackupTimer);
    autoBackupTimer = null;
  }
}
